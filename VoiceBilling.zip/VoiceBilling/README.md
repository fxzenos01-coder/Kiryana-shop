# Voice Billing

Android billing app for shopkeepers with an optional AI voice assistant (English, Roman Urdu, Urdu).
Everything is saved on the phone (Room database). Product matching, aliases, units and bill maths work offline.

See `PROJECT_BRIEF.md` for goals, rules and design.

## What the app does

- **AI Voice Billing** button (separate from manual entry). Voice never starts on its own: you press the microphone.
- Language buttons: English, Roman Urdu, Urdu. Change any time.
- Say: "Ek kilo basmati chawal, aadha kilo cheeni, ek kilo zeera".
  The app shows each item as Matched, Check spelling, or New product.
- New product: **Add New Product** opens a small form (names, category, unit, purchase and selling price, stock). It is saved permanently and found by voice next time.
- Confirmation screen: edit names, quantities, units and rates, remove or add items, then **Confirm & Save Bill**. Nothing is saved before that.
- If voice is unavailable or unreliable, type the sentence in the box and press **Interpret text**.

## First use

1. Open the app, tap **Products** and add a few products (or just start billing and add them as the app asks).
2. Tap **AI Voice Billing**, choose a language, tap the microphone, speak, tap Stop.
3. Check every line, then **Confirm**.

For voice to work offline on the phone: Settings > Apps > Google > (or "Speech Services by Google") > Offline speech recognition > download English and Urdu. Without that pack, the phone's speech service may need internet; the typing box always works offline.

---

# Put it on GitHub and build the APK (no Android Studio needed)

You only need a GitHub account and Git.

## A. One-time setup

1. Create a free account at https://github.com
2. Install Git: https://git-scm.com/downloads (accept the defaults).
3. On GitHub click **New repository**. Name it `VoiceBilling`. Leave "Add a README" unticked. Click **Create repository**. Copy the repository address it shows (looks like `https://github.com/YOURNAME/VoiceBilling.git`).

## B. Upload the project

Unzip `VoiceBilling.zip`, open a terminal (on Windows: right-click inside the folder > "Open in Terminal" or "Git Bash") **inside the VoiceBilling folder** and run:

```
git init
git add .
git commit -m "Voice Billing first version"
git branch -M main
git remote add origin https://github.com/YOURNAME/VoiceBilling.git
git push -u origin main
```

Replace `YOURNAME` with your GitHub username. When asked, sign in to GitHub in the window that opens.
(`git add .` includes the hidden `.github` folder, which holds the build recipe. Uploading files by drag-and-drop on the website often skips it, so use the commands.)

## C. Build the APK

1. On your repository page open the **Actions** tab. The workflow **Build APK** starts by itself after the push (first run takes about 5-10 minutes). If it did not start, click **Build APK** > **Run workflow**.
2. When it shows a green tick, click the run, scroll to **Artifacts**, and download **VoiceBilling-debug-apk**.
3. Unzip the download. Inside is `app-debug.apk`.

If the run shows a red cross: click it, open the failed step, copy the first red error line(s) and send them to me with `PROJECT_BRIEF.md`. This is the first time the Android part is compiled, so a small fix may be needed.

## D. Install and share the APK

- Send `app-debug.apk` through Google Drive, Telegram, email or a USB cable. (WhatsApp may refuse .apk files; if so rename it to `app-debug.zip`, send it, and the receiver renames it back.)
- On the receiving phone: open the file. Android asks to allow **Install unknown apps** for the app you opened it from (Files, Chrome, Drive...). Allow it, then install. If Play Protect warns, choose **Install anyway** (the app is not from the Play Store).
- The first time you tap the microphone, allow the microphone permission.

The debug APK is signed with a debug key, which is fine for sharing with a few people. A Play Store release needs your own signing key (see the ideas in `PROJECT_BRIEF.md`).

## E. Updating the app later

Change files, then:

```
git add .
git commit -m "describe the change"
git push
```

A new APK is built automatically in the Actions tab.

---

# Alternative: build with Android Studio

1. Install Android Studio (https://developer.android.com/studio).
2. **Open** the `VoiceBilling` folder, let Gradle sync (needs internet the first time).
3. Plug in a phone with USB debugging, or use an emulator, and press Run.
4. To get an APK file: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. It is created at `app/build/outputs/apk/debug/app-debug.apk`.

Command line instead: `./gradlew :app:assembleDebug` (Windows: `gradlew.bat :app:assembleDebug`). Needs JDK 17 and the Android SDK.

# Running the logic tests

`./gradlew :app:testDebugUnitTest`

The tests cover the voice parser, product matcher, dictionary and unit conversion.

# Project layout

```
app/src/main/java/com/shopkeeper/voicebilling/
  logic/   parser, matcher, dictionary, units (pure Kotlin, tested)
  data/    Room database: products, aliases, bills
  speech/  wrapper around the phone's speech recogniser
  ui/      screens and ViewModel
.github/workflows/build-apk.yml   builds the APK on GitHub
```

# Honest limits

- Speech recognition can make mistakes, which is why every voice bill goes through a confirmation screen.
- Roman Urdu is recognised through the phone's Urdu recogniser (Urdu script), then matched to your products and aliases.
- Offline voice depends on the offline language pack installed on the phone; the app does not bundle its own speech model.
