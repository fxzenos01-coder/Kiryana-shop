package com.shopkeeper.voicebilling.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LogicTest {

    private val catalog = listOf(
        CatalogEntry(1, "Basmati Rice", listOf("Basmati Rice", "Basmati Chawal", "باسمتی چاول")),
        CatalogEntry(2, "Sugar", listOf("Sugar", "Cheeni", "چینی")),
        CatalogEntry(3, "Cooking Oil", listOf("Cooking Oil", "Tel", "تیل")),
        CatalogEntry(4, "Sesame", listOf("Sesame", "Til", "تل"))
    )

    // ---------- parser ----------

    @Test fun english_sentence() {
        val r = VoiceParser.parse("One kilogram rice and half kilogram sugar.")
        assertEquals(2, r.size)
        assertEquals("rice", r[0].spokenName); assertEquals(1.0, r[0].quantity!!, 1e-9); assertEquals("kg", r[0].unit)
        assertEquals("sugar", r[1].spokenName); assertEquals(0.5, r[1].quantity!!, 1e-9); assertEquals("kg", r[1].unit)
    }

    @Test fun roman_urdu_sentence() {
        val r = VoiceParser.parse("Ek kilo chawal aur aadha kilo cheeni.")
        assertEquals(2, r.size)
        assertEquals("chawal", r[0].spokenName); assertEquals(1.0, r[0].quantity!!, 1e-9)
        assertEquals("cheeni", r[1].spokenName); assertEquals(0.5, r[1].quantity!!, 1e-9)
    }

    @Test fun urdu_sentence() {
        val r = VoiceParser.parse("ایک کلو چاول اور آدھا کلو چینی")
        assertEquals(2, r.size)
        assertEquals("چاول", r[0].spokenName); assertEquals(1.0, r[0].quantity!!, 1e-9); assertEquals("kg", r[0].unit)
        assertEquals("چینی", r[1].spokenName); assertEquals(0.5, r[1].quantity!!, 1e-9); assertEquals("kg", r[1].unit)
    }

    @Test fun three_items_with_commas() {
        val r = VoiceParser.parse("Ek kilo basmati chawal, aadha kilo cheeni, ek kilo zeera.")
        assertEquals(3, r.size)
        assertEquals("basmati chawal", r[0].spokenName)
        assertEquals("zeera", r[2].spokenName)
        assertEquals(1.0, r[2].quantity!!, 1e-9)
    }

    @Test fun compound_and_fraction_words() {
        assertEquals(1.5, VoiceParser.parse("one and a half kg sugar")[0].quantity!!, 1e-9)
        assertEquals(2.5, VoiceParser.parse("dhai kilo aata")[0].quantity!!, 1e-9)
        assertEquals(1.5, VoiceParser.parse("derh kilo cheeni")[0].quantity!!, 1e-9)
        assertEquals(0.75, VoiceParser.parse("pona kilo chawal")[0].quantity!!, 1e-9)
        assertEquals(250.0, VoiceParser.parse("dhai sau gram haldi")[0].quantity!!, 1e-9)
        assertEquals("g", VoiceParser.parse("dhai sau gram haldi")[0].unit)
    }

    @Test fun paon_is_quarter_kilo() {
        val r = VoiceParser.parse("ek paon cheeni")[0]
        assertEquals(0.25, r.quantity!!, 1e-9); assertEquals("kg", r.unit)
    }

    @Test fun digits_attached_to_units() {
        val r = VoiceParser.parse("500g sugar and 2.5kg rice")
        assertEquals(500.0, r[0].quantity!!, 1e-9); assertEquals("g", r[0].unit)
        assertEquals(2.5, r[1].quantity!!, 1e-9); assertEquals("kg", r[1].unit)
    }

    @Test fun unclear_quantity_stays_null() {
        val r = VoiceParser.parse("kilo cheeni")[0]
        assertNull(r.quantity)
        assertEquals("kg", r.unit)
        assertNull(VoiceParser.parse("chawal")[0].quantity)
    }

    @Test fun trailing_do_means_give() {
        val r = VoiceParser.parse("ek kilo chawal do")
        assertEquals(1, r.size)
        assertEquals(1.0, r[0].quantity!!, 1e-9)
        assertEquals("chawal", r[0].spokenName)
    }

    @Test fun two_numbers_are_not_guessed() {
        val r = VoiceParser.parse("ek do kilo chawal")[0]
        assertNull(r.quantity)
        assertNotNull(r.note)
    }

    // ---------- matcher ----------

    @Test fun spelling_variants_match_same_product() {
        for (s in listOf("cheeni", "chini", "CHEENI", "چینی")) {
            val m = ProductMatcher.match(s, catalog)
            assertTrue("$s -> $m", m is MatchResult.Matched && m.productId == 2L)
        }
        val m = ProductMatcher.match("basmati chaawal", catalog)
        assertTrue(m is MatchResult.Matched && m.productId == 1L)
    }

    @Test fun similar_but_different_is_never_auto_matched() {
        // "til" (sesame) and "tel" (oil) differ by one letter: must not silently map
        val m = ProductMatcher.match("tel", catalog)
        assertTrue(m is MatchResult.Matched && m.productId == 3L)
        val til = ProductMatcher.match("til", catalog)
        assertTrue(til is MatchResult.Matched && til.productId == 4L)
    }

    @Test fun close_spelling_shows_suggestions_not_a_match() {
        val m = ProductMatcher.match("basmti chawal", catalog)
        assertTrue("got $m", m is MatchResult.Uncertain)
        assertEquals(1L, (m as MatchResult.Uncertain).candidates[0].productId)
    }

    @Test fun partial_name_is_uncertain() {
        val m = ProductMatcher.match("basmati", catalog)
        assertTrue("got $m", m is MatchResult.Uncertain)
    }

    @Test fun unknown_product_is_not_found() {
        assertTrue(ProductMatcher.match("zeera", catalog) is MatchResult.NotFound)
        assertTrue(ProductMatcher.match("", catalog) is MatchResult.NotFound)
    }

    // ---------- dictionary ----------

    @Test fun dictionary_suggests_correct_spelling() {
        assertEquals("Cumin", Dictionary.suggest("zeera")!!.english)
        assertEquals("Cumin", Dictionary.suggest("jeera")!!.english)
        assertEquals("Turmeric", Dictionary.suggest("haldi")!!.english)
        assertEquals("Red Chilli", Dictionary.suggest("lal mirch")!!.english)
        assertEquals("Flour", Dictionary.suggest("آٹا")!!.english)
        assertEquals("Flour", Dictionary.suggest("atta")!!.english)
        assertEquals("Coriander", Dictionary.suggest("dhaniya")!!.english)
        assertNull(Dictionary.suggest("xyzzyplugh"))
    }

    @Test fun dictionary_label_follows_language() {
        val cumin = Dictionary.suggest("zeera")!!
        assertEquals("Zeera (Cumin)", cumin.label(AppLanguage.ROMAN_URDU))
        assertEquals("Cumin (Zeera)", cumin.label(AppLanguage.ENGLISH))
        assertEquals("زیرہ (Cumin)", cumin.label(AppLanguage.URDU))
    }

    @Test fun dictionary_has_no_spelling_collisions() {
        assertEquals(emptyList<String>(), Dictionary.hasKeyCollisions())
    }

    @Test fun builtin_names_expand_existing_products() {
        val sugar = CatalogEntry(1, "Sugar", Dictionary.expand(listOf("Sugar")))
        val rice = CatalogEntry(2, "Rice", Dictionary.expand(listOf("Rice")))
        val basmati = CatalogEntry(3, "Basmati Rice", Dictionary.expand(listOf("Basmati Rice")))
        val cat = listOf(sugar, rice, basmati)
        val a = ProductMatcher.match("چینی", cat)
        assertTrue("got $a", a is MatchResult.Matched && a.productId == 1L)
        val b = ProductMatcher.match("cheeni", cat)
        assertTrue("got $b", b is MatchResult.Matched && b.productId == 1L)
        val c = ProductMatcher.match("chawal", cat)
        assertTrue("got $c", c is MatchResult.Matched && c.productId == 2L)
        val d = ProductMatcher.match("basmati chawal", cat)
        assertTrue("got $d", d is MatchResult.Matched && d.productId == 3L)
        // a product with an unrelated name is never expanded
        assertEquals(listOf("Soap Bar"), Dictionary.expand(listOf("Soap Bar")))
    }

    @Test fun items_without_connector_are_split() {
        val r = VoiceParser.parse("ek kilo chawal do kilo cheeni")
        assertEquals(2, r.size)
        assertEquals("chawal", r[0].spokenName); assertEquals(1.0, r[0].quantity!!, 1e-9)
        assertEquals("cheeni", r[1].spokenName); assertEquals(2.0, r[1].quantity!!, 1e-9)
        val r2 = VoiceParser.parse("ek kilo chawal aadha kilo cheeni paanch sau gram haldi")
        assertEquals(3, r2.size)
        assertEquals(500.0, r2[2].quantity!!, 1e-9); assertEquals("g", r2[2].unit)
        // trailing "do" still means "give"
        assertEquals(1, VoiceParser.parse("ek kilo chawal do").size)
    }

    // ---------- units ----------

    @Test fun unit_conversion() {
        assertEquals(0.5, Units.convert(500.0, "g", "kg")!!, 1e-9)
        assertEquals(2000.0, Units.convert(2.0, "kg", "g")!!, 1e-9)
        assertEquals(24.0, Units.convert(2.0, "dozen", "piece")!!, 1e-9)
        assertNull(Units.convert(1.0, "kg", "l"))
        assertEquals("0.5", Units.formatQty(0.5))
        assertEquals("1", Units.formatQty(1.0))
        assertEquals("Rs. 80", Units.formatMoney(80.0))
        assertEquals("Rs. 12.50", Units.formatMoney(12.5))
    }
}
