@file:OptIn(ExperimentalMaterial3Api::class)

package com.shopkeeper.voicebilling.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.shopkeeper.voicebilling.data.Product
import com.shopkeeper.voicebilling.data.ProductAlias
import com.shopkeeper.voicebilling.data.Repository
import com.shopkeeper.voicebilling.logic.AppLanguage
import com.shopkeeper.voicebilling.logic.ProductMatcher
import com.shopkeeper.voicebilling.logic.Units

private val decimalKeyboard = KeyboardOptions(keyboardType = KeyboardType.Decimal)

@Composable
fun UnitDropdown(
    unit: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    isError: Boolean = false
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(
            onClick = { open = true },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            contentPadding = PaddingValues(horizontal = 8.dp),
            border = BorderStroke(
                1.dp,
                if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline
            ),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
            )
        ) {
            Text(if (unit.isBlank()) "Choose unit" else unit)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            Units.all.forEach { u ->
                DropdownMenuItem(text = { Text(u) }, onClick = { onSelect(u); open = false })
            }
        }
    }
}

private fun statusColor(s: LineStatus): Color = when (s) {
    LineStatus.MATCHED, LineStatus.MANUAL -> Color(0xFF2E7D32)
    LineStatus.UNCERTAIN -> Color(0xFFE65100)
    LineStatus.NEW -> Color(0xFF1565C0)
    LineStatus.UNCLEAR -> Color(0xFFB3261D)
}

/** One editable bill row: product, quantity, unit, rate, total, plus the actions its status needs. */
@Composable
fun LineCard(
    line: DraftLine,
    products: List<Product>,
    language: AppLanguage,
    onQty: (String) -> Unit,
    onRate: (String) -> Unit,
    onUnit: (String) -> Unit,
    onRemove: () -> Unit,
    onPickProduct: () -> Unit,
    onChooseSuggestion: (Long) -> Unit,
    onAddNew: () -> Unit
) {
    val name = lineName(line, products, language)
    val needsProduct = line.productId == null
    Card(
        modifier = Modifier.fillMaxWidth(),
        border = if (line.isComplete) null else BorderStroke(1.dp, MaterialTheme.colorScheme.error),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable(onClick = onPickProduct)) {
                    Text(name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = line.status.label + if (needsProduct) "" else " - tap name to change",
                        style = MaterialTheme.typography.labelMedium,
                        color = statusColor(line.status)
                    )
                }
                IconButton(onClick = onRemove) {
                    Icon(Icons.Filled.Delete, contentDescription = "Remove item")
                }
            }

            if (line.status == LineStatus.UNCERTAIN && line.suggestions.isNotEmpty()) {
                Text(
                    "Heard \"${line.spokenText}\". Did you mean:",
                    style = MaterialTheme.typography.bodySmall
                )
                line.suggestions.forEach { c ->
                    val label = products.firstOrNull { it.id == c.productId }?.label(language) ?: c.displayName
                    OutlinedButton(
                        onClick = { onChooseSuggestion(c.productId) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(label) }
                }
            }

            if (needsProduct) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onAddNew, modifier = Modifier.weight(1f)) { Text("Add New Product") }
                    OutlinedButton(onClick = onPickProduct, modifier = Modifier.weight(1f)) { Text("Pick existing") }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = line.qtyText,
                    onValueChange = onQty,
                    label = { Text("Quantity") },
                    singleLine = true,
                    keyboardOptions = decimalKeyboard,
                    isError = line.quantity == null,
                    modifier = Modifier.weight(1f)
                )
                UnitDropdown(
                    unit = line.unit,
                    onSelect = onUnit,
                    isError = line.unit.isBlank(),
                    modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = line.rateText,
                    onValueChange = onRate,
                    label = { Text("Rate (Rs.)") },
                    singleLine = true,
                    keyboardOptions = decimalKeyboard,
                    isError = line.rate == null,
                    modifier = Modifier.weight(1f)
                )
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                    val t = line.total
                    Text(
                        text = if (t != null) Units.formatMoney(t) else "Pending",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            line.parseNote?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
            line.note?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = Color(0xFFE65100))
            }
        }
    }
}

@Composable
private fun ProductRow(p: Product, language: AppLanguage, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp)
    ) {
        Text(
            p.label(language),
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
        val price = p.sellingPrice?.let { Units.formatMoney(it) } ?: "no price"
        Text("per ${p.unit} - $price", style = MaterialTheme.typography.bodySmall)
    }
    HorizontalDivider()
}

@Composable
fun ProductPickerDialog(
    products: List<Product>,
    aliases: List<ProductAlias>,
    language: AppLanguage,
    onPick: (Product) -> Unit,
    onCreateNew: () -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val catalog = remember(products, aliases) { Repository.buildCatalog(products, aliases) }
    val results = remember(query, catalog, products) {
        ProductMatcher.search(query, catalog)
            .mapNotNull { c -> products.firstOrNull { it.id == c.productId } }
            .take(10)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose product") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Search (English, Roman Urdu or Urdu)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (results.isEmpty()) {
                    Text("No matching product.", modifier = Modifier.padding(top = 12.dp))
                }
                results.forEach { p -> ProductRow(p, language, false) { onPick(p) } }
            }
        },
        confirmButton = { TextButton(onClick = onCreateNew) { Text("New product") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddItemDialog(
    products: List<Product>,
    aliases: List<ProductAlias>,
    language: AppLanguage,
    onAdd: (Product, String, String) -> Unit,
    onCreateNew: () -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Product?>(null) }
    var qty by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("") }
    val catalog = remember(products, aliases) { Repository.buildCatalog(products, aliases) }
    val results = remember(query, catalog, products) {
        ProductMatcher.search(query, catalog)
            .mapNotNull { c -> products.firstOrNull { it.id == c.productId } }
            .take(6)
    }
    val qtyValue = qty.toDoubleOrNull()
    val chosen = selected
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add item") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Search product") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (products.isEmpty()) {
                    Text("No products yet. Create one first.")
                }
                results.forEach { p ->
                    ProductRow(p, language, chosen?.id == p.id) {
                        selected = p
                        unit = p.unit
                    }
                }
                TextButton(onClick = onCreateNew) { Text("Create new product") }
                if (chosen != null) {
                    Text("Selected: ${chosen.label(language)}", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = qty,
                            onValueChange = { v -> qty = v.filter { it.isDigit() || it == '.' } },
                            label = { Text("Quantity") },
                            singleLine = true,
                            keyboardOptions = decimalKeyboard,
                            modifier = Modifier.weight(1f)
                        )
                        UnitDropdown(unit = unit, onSelect = { unit = it }, modifier = Modifier.weight(1f))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = chosen != null && qtyValue != null && qtyValue > 0.0 && unit.isNotBlank(),
                onClick = { if (chosen != null) onAdd(chosen, qty, unit) }
            ) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ProductEditorDialog(
    state: EditorState,
    language: AppLanguage,
    aliases: List<ProductAlias>,
    onSave: (ProductForm) -> Unit,
    onDismiss: () -> Unit,
    onUseExisting: () -> Unit,
    onDelete: (Product) -> Unit,
    onAddAlias: (Long, String) -> Unit,
    onDeleteAlias: (Long) -> Unit
) {
    var form by remember(state.openId) { mutableStateOf(state.initial) }
    var confirmDelete by remember(state.openId) { mutableStateOf(false) }
    var newAlias by remember(state.openId) { mutableStateOf("") }
    val editing = state.editing

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (editing != null) "Edit product" else "Add New Product") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                state.suggestionNote?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = Color(0xFF1565C0))
                }
                OutlinedTextField(
                    value = form.name, onValueChange = { form = form.copy(name = it) },
                    label = { Text("Product name *") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = form.urdu, onValueChange = { form = form.copy(urdu = it) },
                    label = { Text("Urdu name (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = form.roman, onValueChange = { form = form.copy(roman = it) },
                    label = { Text("Roman Urdu name (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = form.english, onValueChange = { form = form.copy(english = it) },
                    label = { Text("English name (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = form.category, onValueChange = { form = form.copy(category = it) },
                    label = { Text("Category") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Text("Measurement unit *", style = MaterialTheme.typography.labelMedium)
                UnitDropdown(
                    unit = form.unit,
                    onSelect = { form = form.copy(unit = it) },
                    isError = form.unit.isBlank(),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = form.purchase,
                    onValueChange = { v -> form = form.copy(purchase = v.filter { it.isDigit() || it == '.' }) },
                    label = { Text("Purchase price (Rs.)") }, singleLine = true,
                    keyboardOptions = decimalKeyboard, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = form.selling,
                    onValueChange = { v -> form = form.copy(selling = v.filter { it.isDigit() || it == '.' }) },
                    label = { Text("Selling price (Rs.) *") }, singleLine = true,
                    keyboardOptions = decimalKeyboard, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = form.stock,
                    onValueChange = { v -> form = form.copy(stock = v.filter { it.isDigit() || it == '.' }) },
                    label = { Text("Initial stock (optional)") }, singleLine = true,
                    keyboardOptions = decimalKeyboard, modifier = Modifier.fillMaxWidth()
                )

                state.error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
                if (state.duplicate != null) {
                    OutlinedButton(onClick = onUseExisting, modifier = Modifier.fillMaxWidth()) {
                        Text("Use existing: ${state.duplicate.label(language)}")
                    }
                }

                if (editing != null) {
                    HorizontalDivider()
                    Text("Other names (aliases) used for voice matching", style = MaterialTheme.typography.labelMedium)
                    val mine = aliases.filter { it.productId == editing.id }
                    if (mine.isEmpty()) Text("None yet", style = MaterialTheme.typography.bodySmall)
                    mine.forEach { a ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(a.alias, modifier = Modifier.weight(1f))
                            TextButton(onClick = { onDeleteAlias(a.id) }) { Text("Remove") }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = newAlias, onValueChange = { newAlias = it },
                            label = { Text("New alias") }, singleLine = true, modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            enabled = newAlias.isNotBlank(),
                            onClick = { onAddAlias(editing.id, newAlias); newAlias = "" }
                        ) { Text("Add") }
                    }
                    Spacer(Modifier.height(4.dp))
                    TextButton(onClick = {
                        if (confirmDelete) onDelete(editing) else confirmDelete = true
                    }) {
                        Text(
                            if (confirmDelete) "Tap again to delete this product" else "Delete product",
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(form) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
