package com.shopkeeper.voicebilling.data

import com.shopkeeper.voicebilling.logic.CatalogEntry
import com.shopkeeper.voicebilling.logic.Dictionary
import com.shopkeeper.voicebilling.logic.MatchResult
import com.shopkeeper.voicebilling.logic.Normalizer
import com.shopkeeper.voicebilling.logic.ProductMatcher
import kotlinx.coroutines.flow.Flow

class Repository(db: AppDatabase) {
    private val productDao = db.productDao()
    private val billDao = db.billDao()

    val products: Flow<List<Product>> = productDao.observeProducts()
    val aliases: Flow<List<ProductAlias>> = productDao.observeAliases()
    val bills: Flow<List<Bill>> = billDao.observeBills()

    /**
     * Adds a product after the caller has checked for duplicates, plus aliases so the product can be
     * found again by spoken variants. Returns the saved product (with its new id).
     */
    suspend fun addProduct(product: Product, extraAliases: List<String>): Product {
        val id = productDao.insertProduct(product.copy(id = 0))
        val saved = product.copy(id = id)
        addAliases(id, extraAliases)
        return saved
    }

    suspend fun updateProduct(product: Product) = productDao.updateProduct(product)

    suspend fun deleteProduct(product: Product) = productDao.deleteProduct(product)

    suspend fun addAliases(productId: Long, aliases: List<String>) {
        aliases.map { Normalizer.alias(it) }
            .filter { it.isNotBlank() }
            .distinct()
            .forEach { productDao.insertAlias(ProductAlias(productId = productId, alias = it)) }
    }

    suspend fun deleteAlias(id: Long) = productDao.deleteAlias(id)

    suspend fun saveBill(bill: Bill, items: List<BillItem>): Long = billDao.saveBill(bill, items)

    suspend fun itemsFor(billId: Long): List<BillItem> = billDao.itemsFor(billId)

    companion object {
        /** Product names + aliases in the form the matcher needs. */
        fun buildCatalog(products: List<Product>, aliases: List<ProductAlias>): List<CatalogEntry> {
            val byProduct = aliases.groupBy { it.productId }
            return products.map { p ->
                val names = listOf(p.name, p.nameUrdu, p.nameRoman, p.nameEnglish)
                    .filter { it.isNotBlank() } + byProduct[p.id].orEmpty().map { it.alias }
                CatalogEntry(p.id, p.name, Dictionary.expand(names))
            }
        }

        /** Exact duplicate (same name after spelling normalisation) and merely similar products. */
        fun checkDuplicates(
            names: List<String>,
            catalog: List<CatalogEntry>,
            products: List<Product>,
            excludeId: Long? = null
        ): Pair<Product?, List<Product>> {
            val usable = catalog.filter { it.productId != excludeId }
            var exact: Product? = null
            val similarIds = LinkedHashSet<Long>()
            for (n in names.filter { it.isNotBlank() }) {
                when (val m = ProductMatcher.match(n, usable)) {
                    is MatchResult.Matched -> if (exact == null) exact = products.firstOrNull { it.id == m.productId }
                    is MatchResult.Uncertain -> m.candidates.forEach { similarIds.add(it.productId) }
                    MatchResult.NotFound -> Unit
                }
            }
            val similar = products.filter { it.id in similarIds && it.id != exact?.id }
            return exact to similar
        }
    }
}
