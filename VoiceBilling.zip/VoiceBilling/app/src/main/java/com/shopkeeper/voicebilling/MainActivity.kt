package com.shopkeeper.voicebilling

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.shopkeeper.voicebilling.ui.VoiceBillingApp
import com.shopkeeper.voicebilling.ui.VoiceBillingTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VoiceBillingTheme {
                VoiceBillingApp()
            }
        }
    }
}
