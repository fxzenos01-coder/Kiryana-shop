package com.shopkeeper.voicebilling.logic

import java.util.Locale

/** Text normalisation shared by the parser, matcher and the alias store. Pure Kotlin, works offline. */
object Normalizer {

    private val junkRegex = Regex("[^\\p{L}\\p{N}\\p{M}./,\\s]")
    private val spaceRegex = Regex("\\s+")
    private val sepRegex = Regex("[,./]")

    /** Lower-cases, unifies Urdu/Arabic letter variants, converts Urdu digits to ASCII and strips noise. */
    fun normalize(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input.lowercase(Locale.ROOT)) {
            when {
                ch in 'ً'..'ٟ' || ch == 'ٰ' || ch == 'ـ' -> Unit
                ch in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
                ch in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                ch == 'ي' || ch == 'ى' || ch == 'ے' -> sb.append('ی')
                ch == 'ك' -> sb.append('ک')
                ch == 'ة' || ch == 'ۃ' || ch == 'ۂ' || ch == 'ە' -> sb.append('ہ')
                ch == 'آ' || ch == 'أ' || ch == 'إ' || ch == 'ٱ' -> sb.append('ا')
                ch == 'ں' -> sb.append('ن')
                ch == '،' || ch == '؛' || ch == '؟' || ch == '۔' -> sb.append(',')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
            .replace(junkRegex, " ")
            .replace(spaceRegex, " ")
            .trim()
    }

    /** Normalised form used when storing and comparing aliases (no separators). */
    fun alias(input: String): String =
        normalize(input).replace(sepRegex, " ").replace(spaceRegex, " ").trim()

    fun containsArabicScript(s: String): Boolean = s.any { it in '؀'..'ۿ' }
}
