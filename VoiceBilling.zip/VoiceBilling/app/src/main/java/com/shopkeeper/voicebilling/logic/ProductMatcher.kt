package com.shopkeeper.voicebilling.logic

/** A catalogue product reduced to what matching needs: all of its names and aliases. */
data class CatalogEntry(
    val productId: Long,
    val displayName: String,
    val names: List<String>
)

data class Candidate(
    val productId: Long,
    val displayName: String,
    val score: Double
)

sealed interface MatchResult {
    /** Same name after spelling normalisation. Still shown to the shopkeeper for confirmation. */
    data class Matched(val productId: Long, val displayName: String) : MatchResult

    /** Close but not identical. Never auto-selected - the shopkeeper chooses. */
    data class Uncertain(val candidates: List<Candidate>) : MatchResult

    /** Nothing similar exists: probably a genuinely new product. */
    data object NotFound : MatchResult
}

/** Product matching and spelling correction. Local only, works offline. */
object ProductMatcher {

    private const val MIN_CANDIDATE_SCORE = 0.6
    private const val MIN_FUZZY_KEY_LENGTH = 4
    private const val CONTAINMENT_SCORE = 0.75
    private const val MAX_CANDIDATES = 4

    private val spaceLike = Regex("[\\s,./]")
    private val afterConsonantH = Regex("(?<=[bcdfgjklmnpqrstvwxyz])h")
    private val repeatedChars = Regex("(.)\\1+")

    /** Phonetic-ish key so spelling variants (chawal / chaawal, cheeni / chini) compare equal. */
    fun key(s: String): String {
        val compact = Normalizer.normalize(s).replace(spaceLike, "")
        return if (Normalizer.containsArabicScript(compact)) compact else latinKey(compact)
    }

    private fun latinKey(x: String): String {
        var s = x.filter { it.isLetterOrDigit() }
        s = s.replace("ph", "f").replace("q", "k")
        s = s.replace(afterConsonantH, "")
        s = s.replace('w', 'v').replace('y', 'i').replace('z', 'j').replace('c', 'k')
        s = s.replace("aa", "a").replace("ee", "i").replace("oo", "u")
            .replace("ii", "i").replace("uu", "u")
        s = s.replace(repeatedChars, "$1")
        return s
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    fun similarity(a: String, b: String): Double {
        val m = maxOf(a.length, b.length)
        if (m == 0) return 1.0
        return 1.0 - levenshtein(a, b).toDouble() / m
    }

    private fun tokenKeys(s: String): List<String> =
        Normalizer.alias(s).split(' ').filter { it.isNotEmpty() }.map { key(it) }.filter { it.isNotEmpty() }

    /** Score of [spoken] against one name: 1.0 only for an identical key. */
    private fun scoreName(spokenKey: String, spokenTokens: List<String>, name: String): Double {
        val nameKey = key(name)
        if (nameKey.isEmpty()) return 0.0
        if (nameKey == spokenKey) return 1.0
        var best = 0.0
        if (minOf(nameKey.length, spokenKey.length) >= MIN_FUZZY_KEY_LENGTH) {
            // never reach 1.0 through fuzziness
            best = minOf(similarity(spokenKey, nameKey), 0.99)
        }
        val nameTokens = tokenKeys(name)
        if (nameTokens.isNotEmpty() && spokenTokens.isNotEmpty() && nameTokens.size != spokenTokens.size) {
            val small = if (nameTokens.size < spokenTokens.size) nameTokens else spokenTokens
            val large = if (nameTokens.size < spokenTokens.size) spokenTokens else nameTokens
            if (small.all { it.length >= 3 && it in large }) best = maxOf(best, CONTAINMENT_SCORE)
        }
        return best
    }

    fun match(spoken: String, catalog: List<CatalogEntry>): MatchResult {
        val spokenKey = key(spoken)
        if (spokenKey.isEmpty()) return MatchResult.NotFound
        val spokenTokens = tokenKeys(spoken)

        val scored = catalog.mapNotNull { entry ->
            val best = entry.names.maxOfOrNull { scoreName(spokenKey, spokenTokens, it) } ?: 0.0
            if (best >= MIN_CANDIDATE_SCORE) Candidate(entry.productId, entry.displayName, best) else null
        }.sortedByDescending { it.score }

        val exact = scored.filter { it.score >= 1.0 }
        if (exact.size == 1) return MatchResult.Matched(exact[0].productId, exact[0].displayName)
        if (exact.size > 1) return MatchResult.Uncertain(exact.take(MAX_CANDIDATES))
        if (scored.isNotEmpty()) return MatchResult.Uncertain(scored.take(MAX_CANDIDATES))
        return MatchResult.NotFound
    }

    /** Best candidates for a typed search (used by the product picker). */
    fun search(query: String, catalog: List<CatalogEntry>): List<Candidate> {
        val q = Normalizer.alias(query)
        if (q.isEmpty()) return catalog.map { Candidate(it.productId, it.displayName, 0.0) }
        val contains = catalog.filter { e -> e.names.any { Normalizer.alias(it).contains(q) } }
            .map { Candidate(it.productId, it.displayName, 1.0) }
        val ids = contains.map { it.productId }.toSet()
        val fuzzy = (match(query, catalog) as? MatchResult.Uncertain)?.candidates.orEmpty()
            .filter { it.productId !in ids }
        val exact = (match(query, catalog) as? MatchResult.Matched)
            ?.takeIf { it.productId !in ids }
            ?.let { listOf(Candidate(it.productId, it.displayName, 1.0)) }.orEmpty()
        return contains + exact + fuzzy
    }
}
