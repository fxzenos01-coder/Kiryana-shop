package com.shopkeeper.voicebilling.ui

import com.shopkeeper.voicebilling.data.Product
import com.shopkeeper.voicebilling.logic.AppLanguage
import com.shopkeeper.voicebilling.logic.Candidate
import com.shopkeeper.voicebilling.logic.DictEntry
import com.shopkeeper.voicebilling.logic.Dictionary
import com.shopkeeper.voicebilling.logic.Units

enum class Screen { BILL, VOICE, CONFIRM, PRODUCTS, HISTORY }

enum class LineStatus(val label: String) {
    MATCHED("Matched"),
    UNCERTAIN("Check spelling"),
    NEW("New product"),
    MANUAL("Confirmed"),
    UNCLEAR("Choose product")
}

/** One row of the bill being built. Numbers are kept as text so partly typed values survive. */
data class DraftLine(
    val id: Long,
    val status: LineStatus,
    val spokenText: String = "",
    val productId: Long? = null,
    val qtyText: String = "",
    val unit: String = "",
    val rateText: String = "",
    val rateEdited: Boolean = false,
    val suggestions: List<Candidate> = emptyList(),
    val dictEntry: DictEntry? = null,
    val parseNote: String? = null,
    val note: String? = null,
    val fromVoice: Boolean = false
) {
    val quantity: Double? get() = qtyText.toDoubleOrNull()?.takeIf { it > 0.0 }
    val rate: Double? get() = rateText.toDoubleOrNull()?.takeIf { it >= 0.0 }
    val total: Double?
        get() {
            val q = quantity
            val r = rate
            return if (q != null && r != null) Units.round2(q * r) else null
        }

    /** Everything needed to put this line on a saved bill is present and confirmed. */
    val isComplete: Boolean
        get() = productId != null && quantity != null && unit.isNotBlank() && rate != null
}

data class ProductForm(
    val name: String = "",
    val urdu: String = "",
    val roman: String = "",
    val english: String = "",
    val category: String = "",
    val unit: String = "",
    val purchase: String = "",
    val selling: String = "",
    val stock: String = ""
)

data class EditorState(
    val openId: Long,
    val forLineId: Long?,
    val addToBill: Boolean,
    val editing: Product?,
    val initial: ProductForm,
    val suggestionNote: String? = null,
    val error: String? = null,
    val duplicate: Product? = null,
    val similarAcknowledged: Boolean = false
)

/** Display name of a line in the selected language. */
fun lineName(line: DraftLine, products: List<Product>, lang: AppLanguage): String {
    val p = line.productId?.let { id -> products.firstOrNull { it.id == id } }
    if (p != null) return p.label(lang)
    line.dictEntry?.let { return it.label(lang) }
    if (line.spokenText.isNotBlank()) {
        return if (line.status == LineStatus.NEW) Dictionary.titleCase(line.spokenText) else line.spokenText
    }
    return "(choose product)"
}
