package com.shopkeeper.voicebilling.logic

/**
 * One spoken/typed item before it is matched to a product.
 * [quantity] or [unit] is null whenever the text did not state it clearly - nothing is guessed.
 */
data class ParsedItem(
    val spokenName: String,
    val quantity: Double?,
    val unit: String?,
    val rawText: String,
    val note: String? = null
)

/** Measurement interpretation: turns text such as "ek kilo chawal aur aadha kilo cheeni" into items. */
object VoiceParser {

    private val commaRegex = Regex("[,]")
    private val strayDotRegex = Regex("(?<!\\d)\\.|\\.(?!\\d)")
    private val digitLetterRegex = Regex("(?<=\\d)(?=[a-zA-Z\\u0600-\\u06FF])|(?<=[a-zA-Z\\u0600-\\u06FF])(?=\\d)")
    private val plainNumberRegex = Regex("^\\d+(\\.\\d+)?$")
    private val fractionRegex = Regex("^(\\d+)/(\\d+)$")
    private val doWords = setOf(Normalizer.normalize("do"), Normalizer.normalize("دو"))
    private val articles = setOf("a", "an")

    fun parse(text: String): List<ParsedItem> {
        val tokens = tokenize(text)
        val merged = mergeNumbers(tokens)
        val items = ArrayList<ParsedItem>()
        var segment = ArrayList<String>()
        for ((i, tok) in merged.withIndex()) {
            if (tok in Lexicon.connectors) {
                parseSegment(segment)?.let { items.add(it) }
                segment = ArrayList()
                continue
            }
            // "ek kilo chawal do kilo cheeni" (no "aur"): a new quantity after a finished
            // quantity + product name starts the next item.
            if (startsNewItem(segment, tok, merged.getOrNull(i + 1))) {
                parseSegment(segment)?.let { items.add(it) }
                segment = ArrayList()
            }
            segment.add(tok)
        }
        parseSegment(segment)?.let { items.add(it) }
        return items
    }

    private fun isNameWord(t: String): Boolean =
        tokenValue(t) == null && t !in Lexicon.fillers && t !in articles &&
            t !in Lexicon.connectors && !Lexicon.units.containsKey(t)

    private fun startsNewItem(segment: List<String>, tok: String, next: String?): Boolean {
        if (next == null || next in Lexicon.connectors) return false
        if (tokenValue(tok) == null) return false
        return segment.any { tokenValue(it) != null } && segment.any { isNameWord(it) }
    }

    private fun tokenize(text: String): List<String> {
        var s = Normalizer.normalize(text)
        s = s.replace(strayDotRegex, " , ")
        s = s.replace(commaRegex, " , ")
        s = s.replace(digitLetterRegex, " ")
        return s.split(' ').filter { it.isNotEmpty() }
    }

    private fun tokenValue(tok: String): Double? {
        if (plainNumberRegex.matches(tok)) return tok.toDoubleOrNull()
        val frac = fractionRegex.matchEntire(tok)
        if (frac != null) {
            val a = frac.groupValues[1].toDouble()
            val b = frac.groupValues[2].toDouble()
            return if (b == 0.0) null else a / b
        }
        return Lexicon.numbers[tok]
    }

    /** Handles "one and a half", "ek aur aadha", "teen sau", "dhai sau". */
    private fun mergeNumbers(tokens: List<String>): List<String> {
        val out = ArrayList<String>()
        var i = 0
        while (i < tokens.size) {
            val tok = tokens[i]
            val v = tokenValue(tok)

            // N and (a) half  ->  N.5
            if (v != null && tok !in Lexicon.halfWords && v == Math.floor(v) &&
                i + 2 < tokens.size && tokens[i + 1] in Lexicon.connectors
            ) {
                var j = i + 2
                if (tokens[j] in articles && j + 1 < tokens.size) j++
                if (tokens[j] in Lexicon.halfWords) {
                    out.add(Units.formatQty(v + 0.5))
                    i = j + 1
                    continue
                }
            }

            // N hundred -> N*100
            if (tok in Lexicon.hundredWords && out.isNotEmpty()) {
                val prev = tokenValue(out.last())
                if (prev != null && prev > 0 && prev < 100) {
                    out[out.size - 1] = Units.formatQty(prev * 100.0)
                    i++
                    continue
                }
            }

            out.add(tok)
            i++
        }
        return out
    }

    private class Num(val value: Double, val index: Int, val token: String)

    private fun parseSegment(seg: List<String>): ParsedItem? {
        if (seg.isEmpty()) return null
        val raw = seg.joinToString(" ")

        val nums = ArrayList<Num>()
        val nameWords = ArrayList<Pair<Int, String>>()
        var unit: String? = null

        for ((idx, tok) in seg.withIndex()) {
            val next = seg.getOrNull(idx + 1)
            when {
                tok in articles && next != null && Lexicon.units.containsKey(next) -> nums.add(Num(1.0, idx, tok))
                tok in articles -> Unit
                tok in Lexicon.fillers -> Unit
                Lexicon.units.containsKey(tok) && unit == null -> unit = Lexicon.units[tok]
                else -> {
                    val v = tokenValue(tok)
                    if (v != null) nums.add(Num(v, idx, tok)) else nameWords.add(idx to tok)
                }
            }
        }

        // "ek kilo chawal do" - a trailing "do" after the product name means "give", not 2.
        if (nums.size > 1) {
            val last = nums.last()
            val lastNameIdx = nameWords.maxOfOrNull { it.first } ?: -1
            if (last.token in doWords && last.index > lastNameIdx) nums.removeAt(nums.size - 1)
        }

        var note: String? = null
        var qty: Double? = null
        when {
            nums.size == 1 -> qty = nums[0].value
            nums.size > 1 -> note = "More than one quantity heard - please set the quantity"
        }
        if (qty != null && qty <= 0.0) {
            qty = null
            note = "Quantity must be above zero"
        }

        if (unit == Lexicon.PAON) {
            qty = (qty ?: 1.0) * 0.25
            unit = Units.KG
        }

        val name = nameWords.joinToString(" ") { it.second }
        if (name.isEmpty() && qty == null && unit == null) return null

        return ParsedItem(
            spokenName = name,
            quantity = qty,
            unit = unit,
            rawText = raw,
            note = note
        )
    }
}
