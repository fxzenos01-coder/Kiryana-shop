package com.shopkeeper.voicebilling.logic

/** Number words, unit words and filler words for English, Roman Urdu and Urdu. */
object Lexicon {

    private fun numTable(vararg pairs: Pair<String, Double>): Map<String, Double> =
        pairs.associate { (k, v) -> Normalizer.normalize(k) to v }

    private fun wordSet(vararg words: String): Set<String> =
        words.map { Normalizer.normalize(it) }.toSet()

    private fun unitTable(vararg pairs: Pair<String, String>): Map<String, String> =
        pairs.associate { (k, v) -> Normalizer.normalize(k) to v }

    /** Spoken words that mean exactly one half. */
    val halfWords: Set<String> = wordSet("half", "aadha", "adha", "aadhi", "adhi", "آدھا", "آدھی", "آدھ")

    val hundredWords: Set<String> = wordSet("hundred", "sau", "سو")

    val numbers: Map<String, Double> = numTable(
        // English
        "zero" to 0.0, "one" to 1.0, "two" to 2.0, "three" to 3.0, "four" to 4.0, "five" to 5.0,
        "six" to 6.0, "seven" to 7.0, "eight" to 8.0, "nine" to 9.0, "ten" to 10.0,
        "eleven" to 11.0, "twelve" to 12.0, "thirteen" to 13.0, "fourteen" to 14.0, "fifteen" to 15.0,
        "sixteen" to 16.0, "seventeen" to 17.0, "eighteen" to 18.0, "nineteen" to 19.0, "twenty" to 20.0,
        "thirty" to 30.0, "forty" to 40.0, "fifty" to 50.0, "hundred" to 100.0,
        "half" to 0.5, "quarter" to 0.25,
        // Roman Urdu
        "ek" to 1.0, "aik" to 1.0, "ik" to 1.0, "do" to 2.0, "teen" to 3.0, "char" to 4.0, "chaar" to 4.0,
        "panch" to 5.0, "paanch" to 5.0, "chhe" to 6.0, "chay" to 6.0, "chhay" to 6.0, "chheh" to 6.0,
        "saat" to 7.0, "aath" to 8.0, "nau" to 9.0, "das" to 10.0, "gyarah" to 11.0, "barah" to 12.0,
        "terah" to 13.0, "chaudah" to 14.0, "pandrah" to 15.0, "bees" to 20.0, "pachees" to 25.0,
        "tees" to 30.0, "chalis" to 40.0, "pachas" to 50.0, "sau" to 100.0,
        "aadha" to 0.5, "adha" to 0.5, "aadhi" to 0.5, "adhi" to 0.5,
        "dhai" to 2.5, "dhaai" to 2.5, "derh" to 1.5, "dedh" to 1.5, "sawa" to 1.25, "pona" to 0.75,
        // Urdu script
        "ایک" to 1.0, "دو" to 2.0, "تین" to 3.0, "چار" to 4.0, "پانچ" to 5.0, "چھ" to 6.0,
        "سات" to 7.0, "آٹھ" to 8.0, "نو" to 9.0, "دس" to 10.0, "گیارہ" to 11.0, "بارہ" to 12.0,
        "تیرہ" to 13.0, "چودہ" to 14.0, "پندرہ" to 15.0, "بیس" to 20.0, "پچیس" to 25.0,
        "تیس" to 30.0, "چالیس" to 40.0, "پچاس" to 50.0, "سو" to 100.0,
        "آدھا" to 0.5, "آدھی" to 0.5, "آدھ" to 0.5,
        "ڈیڑھ" to 1.5, "ڈھائی" to 2.5, "ڈھائ" to 2.5, "سوا" to 1.25, "پونا" to 0.75
    )

    /** Unit words mapped to canonical units. "paon" (a quarter kilo) is handled by the parser. */
    const val PAON = "paon"

    val units: Map<String, String> = unitTable(
        "kg" to Units.KG, "kgs" to Units.KG, "kilo" to Units.KG, "kilos" to Units.KG,
        "kilogram" to Units.KG, "kilograms" to Units.KG, "kilogramme" to Units.KG,
        "کلو" to Units.KG, "کلوگرام" to Units.KG, "کیلو" to Units.KG, "کیلوگرام" to Units.KG,
        "g" to Units.G, "gm" to Units.G, "gms" to Units.G, "gram" to Units.G, "grams" to Units.G,
        "گرام" to Units.G,
        "l" to Units.L, "ltr" to Units.L, "litre" to Units.L, "liter" to Units.L, "litres" to Units.L,
        "liters" to Units.L, "لیٹر" to Units.L, "لٹر" to Units.L,
        "ml" to Units.ML, "millilitre" to Units.ML, "milliliter" to Units.ML,
        "dozen" to Units.DOZEN, "darjan" to Units.DOZEN, "darzan" to Units.DOZEN, "درجن" to Units.DOZEN,
        "piece" to Units.PIECE, "pieces" to Units.PIECE, "pc" to Units.PIECE, "pcs" to Units.PIECE,
        "dana" to Units.PIECE, "dane" to Units.PIECE, "adad" to Units.PIECE,
        "دانہ" to Units.PIECE, "دانے" to Units.PIECE, "عدد" to Units.PIECE,
        "packet" to Units.PACK, "packets" to Units.PACK, "pack" to Units.PACK, "packs" to Units.PACK,
        "pakat" to Units.PACK, "پیکٹ" to Units.PACK,
        "pao" to PAON, "paon" to PAON, "pau" to PAON, "پاؤ" to PAON, "پاو" to PAON
    )

    val connectors: Set<String> = wordSet("and", "aur", "اور", "plus", "phir", "then", "also", ",")

    val fillers: Set<String> = wordSet(
        "of", "the", "please", "pls", "mujhe", "mujhay", "hamen", "humein", "hamein", "chahiye", "chahiyeh",
        "chahye", "dena", "dijiye", "dijye", "dijiyega", "de", "dedo", "den", "ka", "ki", "ke", "ko", "bhi",
        "wala", "wali", "add", "give", "me", "i", "want", "need", "kar", "karo", "likho", "likh", "bill",
        "مجھے", "چاہیے", "چاہئے", "دیں", "دیجیے", "دیجئے", "دے", "کا", "کی", "کے", "کو", "بھی", "والا", "والی"
    )
}
