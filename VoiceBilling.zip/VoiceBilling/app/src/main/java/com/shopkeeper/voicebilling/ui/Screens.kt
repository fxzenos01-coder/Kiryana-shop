@file:OptIn(ExperimentalMaterial3Api::class)

package com.shopkeeper.voicebilling.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.shopkeeper.voicebilling.data.BillItem
import com.shopkeeper.voicebilling.logic.AppLanguage
import com.shopkeeper.voicebilling.logic.Units
import com.shopkeeper.voicebilling.speech.SpeechController
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------------------
// Shared pieces
// ---------------------------------------------------------------------------

@Composable
private fun EditableLine(vm: BillViewModel, line: DraftLine) {
    val products by vm.products.collectAsState()
    LineCard(
        line = line,
        products = products,
        language = vm.language,
        onQty = { vm.updateQty(line.id, it) },
        onRate = { vm.updateRate(line.id, it) },
        onUnit = { vm.updateUnit(line.id, it) },
        onRemove = { vm.removeLine(line.id) },
        onPickProduct = { vm.pickerForLineId = line.id },
        onChooseSuggestion = { pid -> vm.chooseSuggestion(line.id, pid) },
        onAddNew = { vm.openEditorForLine(line.id) }
    )
}

@Composable
private fun BillTotals(vm: BillViewModel) {
    val lines = vm.lines
    val total = lines.mapNotNull { it.total }.sum()
    val pending = lines.count { !it.isComplete }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Total", style = MaterialTheme.typography.titleLarge)
            Text(Units.formatMoney(Units.round2(total)), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        if (pending > 0) {
            Text(
                "$pending item(s) still need a product, quantity, unit or rate.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

// ---------------------------------------------------------------------------
// 1. Main bill screen (manual entry + separate voice button)
// ---------------------------------------------------------------------------

@Composable
fun BillScreen(vm: BillViewModel, padding: PaddingValues) {
    val lines = vm.lines
    Column(Modifier.padding(padding).fillMaxSize()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { vm.startVoiceSession() },
                modifier = Modifier.fillMaxWidth().height(64.dp)
            ) {
                Icon(Icons.Filled.Mic, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("AI Voice Billing", style = MaterialTheme.typography.titleMedium)
            }
            OutlinedButton(onClick = { vm.showAddItem = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Add item manually")
            }
        }

        if (lines.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    "No items yet.\nUse AI Voice Billing or add items manually.",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(lines, key = { it.id }) { line -> EditableLine(vm, line) }
            }
        }

        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            BillTotals(vm)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { vm.clearBill() },
                    enabled = lines.isNotEmpty(),
                    modifier = Modifier.weight(1f)
                ) { Text("Clear") }
                Button(
                    onClick = { vm.screen = Screen.CONFIRM },
                    enabled = lines.isNotEmpty(),
                    modifier = Modifier.weight(2f)
                ) { Text("Review & Confirm") }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// 2. Voice assistant screen
// ---------------------------------------------------------------------------

@Composable
fun VoiceScreen(vm: BillViewModel, padding: PaddingValues) {
    val context = LocalContext.current
    val controller = remember {
        SpeechController(context, object : SpeechController.Listener {
            override fun onListeningChanged(listening: Boolean) {
                vm.listening = listening
                if (!listening) vm.partialText = ""
            }

            override fun onPartial(text: String) {
                vm.partialText = text
            }

            override fun onFinal(text: String, confidence: Float?) {
                vm.onSpeechFinal(text, confidence)
            }

            override fun onError(message: String) {
                vm.onSpeechError(message)
            }
        })
    }
    DisposableEffect(Unit) {
        onDispose {
            controller.destroy()
            vm.listening = false
            vm.partialText = ""
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            controller.start(vm.language.speechTag)
        } else {
            vm.onSpeechError("Microphone permission was denied. You can still type the bill below.")
        }
    }

    fun startListening() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) controller.start(vm.language.speechTag)
        else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    val sessionLines = vm.lines.filter { it.id in vm.voiceSessionIds }

    LazyColumn(
        modifier = Modifier.padding(padding).fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(Modifier.fillMaxWidth()) {
                Text("Language", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                    AppLanguage.entries.forEach { lang ->
                        FilterChip(
                            selected = vm.language == lang,
                            onClick = { vm.language = lang },
                            label = { Text(lang.label) }
                        )
                    }
                }
            }
        }

        item {
            val pulse = rememberInfiniteTransition(label = "pulse")
            val scale by pulse.animateFloat(
                initialValue = 1f,
                targetValue = 1.15f,
                animationSpec = infiniteRepeatable(tween(600), RepeatMode.Reverse),
                label = "scale"
            )
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Button(
                    onClick = { if (vm.listening) controller.stop() else startListening() },
                    shape = CircleShape,
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier
                        .size(96.dp)
                        .graphicsLayer {
                            val s = if (vm.listening) scale else 1f
                            scaleX = s
                            scaleY = s
                        },
                    colors = if (vm.listening) {
                        ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    } else {
                        ButtonDefaults.buttonColors()
                    }
                ) {
                    Icon(
                        if (vm.listening) Icons.Filled.Stop else Icons.Filled.Mic,
                        contentDescription = if (vm.listening) "Stop listening" else "Start listening",
                        modifier = Modifier.size(44.dp)
                    )
                }
                Spacer(Modifier.height(8.dp))
                if (vm.listening) {
                    Text(
                        "Listening... speak now",
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Bold
                    )
                    LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 6.dp))
                    if (vm.partialText.isNotBlank()) {
                        Text(vm.partialText, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 6.dp))
                    }
                } else {
                    Text("Press the microphone to start. It never listens on its own.")
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { controller.stop() },
                    enabled = vm.listening,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Stop, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Stop")
                }
                OutlinedButton(
                    onClick = {
                        controller.cancel()
                        vm.cancelVoice()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Close, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Cancel")
                }
                Button(
                    onClick = {
                        controller.cancel()
                        vm.confirmVoice()
                    },
                    enabled = sessionLines.isNotEmpty(),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Confirm")
                }
            }
        }

        vm.voiceMessage?.let { msg ->
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Text(msg, modifier = Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
        }

        if (vm.heardText.isNotBlank()) {
            item {
                Text("Heard: \"${vm.heardText}\"", style = MaterialTheme.typography.bodyMedium)
            }
        }

        item {
            Column(Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = vm.inputText,
                    onValueChange = { vm.inputText = it },
                    label = { Text("Type or correct the bill here") },
                    placeholder = { Text("ek kilo chawal aur aadha kilo cheeni") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions.Default
                )
                Spacer(Modifier.height(6.dp))
                Button(
                    onClick = { vm.interpretInput() },
                    enabled = vm.inputText.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Interpret text") }
            }
        }

        item {
            Column(Modifier.fillMaxWidth()) {
                Text("Recognized products", style = MaterialTheme.typography.titleMedium)
                if (sessionLines.isEmpty()) {
                    Text("Nothing recognised yet.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        items(sessionLines, key = { it.id }) { line -> EditableLine(vm, line) }

        item {
            Column(Modifier.fillMaxWidth()) {
                Text(
                    "Speech recognition only turns your voice into text. Product matching, spelling " +
                        "correction, units and bill maths are separate offline steps. Nothing is saved " +
                        "until you confirm the whole bill. Recognition can make mistakes, so check every line.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Offline: matching, aliases, units and calculations always work offline. Voice " +
                        "recognition runs on your phone's speech service and is offline only if that " +
                        "language's offline pack is installed. Typing always works offline.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// 3. Confirmation screen
// ---------------------------------------------------------------------------

@Composable
fun ConfirmScreen(vm: BillViewModel, padding: PaddingValues) {
    val lines = vm.lines
    Column(Modifier.padding(padding).fillMaxSize()) {
        Text(
            "Check every line. You can edit names, quantities, units and rates, remove wrong lines or add missing products.",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(16.dp)
        )
        if (lines.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("The bill is empty.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(lines, key = { it.id }) { line -> EditableLine(vm, line) }
            }
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.showAddItem = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Add missing product")
            }
            BillTotals(vm)
            Button(
                onClick = { vm.confirmBill() },
                enabled = vm.canConfirm,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Confirm & Save Bill") }
        }
    }
}

// ---------------------------------------------------------------------------
// 4. Products screen
// ---------------------------------------------------------------------------

@Composable
fun ProductsScreen(vm: BillViewModel, padding: PaddingValues) {
    val products by vm.products.collectAsState()
    Column(Modifier.padding(padding).fillMaxSize()) {
        Button(
            onClick = { vm.openEditorNew(false) },
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Add product")
        }
        if (products.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No products yet. Add products or create them while billing.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(products, key = { it.id }) { p ->
                    Card(Modifier.fillMaxWidth().clickable { vm.openEditorEdit(p) }) {
                        Column(Modifier.padding(12.dp)) {
                            Text(p.label(vm.language), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            val price = p.sellingPrice?.let { Units.formatMoney(it) } ?: "no price"
                            Text("per ${p.unit} - $price", style = MaterialTheme.typography.bodyMedium)
                            if (p.category.isNotBlank()) Text(p.category, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// 5. History screen
// ---------------------------------------------------------------------------

@Composable
fun HistoryScreen(vm: BillViewModel, padding: PaddingValues) {
    val bills by vm.bills.collectAsState()
    var expanded by remember { mutableStateOf<Long?>(null) }
    val fmt = remember { SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()) }

    if (bills.isEmpty()) {
        Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No saved bills yet.")
        }
        return
    }
    LazyColumn(
        modifier = Modifier.padding(padding).fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(bills, key = { it.id }) { bill ->
            Card(Modifier.fillMaxWidth().clickable { expanded = if (expanded == bill.id) null else bill.id }) {
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Bill #${bill.id}", fontWeight = FontWeight.SemiBold)
                        Text(Units.formatMoney(bill.total), fontWeight = FontWeight.Bold)
                    }
                    Text(fmt.format(Date(bill.createdAt)), style = MaterialTheme.typography.bodySmall)
                    if (expanded == bill.id) {
                        val billItems by produceState(emptyList<BillItem>(), bill.id) {
                            value = vm.billItems(bill.id)
                        }
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        billItems.forEach { it2 ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(
                                    "${it2.name} - ${Units.formatQty(it2.quantity)} ${it2.unit} x ${Units.formatMoney(it2.rate)}",
                                    modifier = Modifier.weight(1f),
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(Units.formatMoney(it2.total), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}
