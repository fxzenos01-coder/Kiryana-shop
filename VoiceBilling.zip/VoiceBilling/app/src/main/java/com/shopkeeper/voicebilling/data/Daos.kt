package com.shopkeeper.voicebilling.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name COLLATE NOCASE")
    fun observeProducts(): Flow<List<Product>>

    @Query("SELECT * FROM product_aliases")
    fun observeAliases(): Flow<List<ProductAlias>>

    @Insert
    suspend fun insertProduct(product: Product): Long

    @Update
    suspend fun updateProduct(product: Product)

    @Delete
    suspend fun deleteProduct(product: Product)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAlias(alias: ProductAlias): Long

    @Query("DELETE FROM product_aliases WHERE id = :id")
    suspend fun deleteAlias(id: Long)
}

@Dao
abstract class BillDao {
    @Insert
    abstract suspend fun insertBill(bill: Bill): Long

    @Insert
    abstract suspend fun insertItems(items: List<BillItem>)

    @Transaction
    open suspend fun saveBill(bill: Bill, items: List<BillItem>): Long {
        val id = insertBill(bill)
        insertItems(items.map { it.copy(billId = id) })
        return id
    }

    @Query("SELECT * FROM bills ORDER BY createdAt DESC")
    abstract fun observeBills(): Flow<List<Bill>>

    @Query("SELECT * FROM bill_items WHERE billId = :billId ORDER BY id")
    abstract suspend fun itemsFor(billId: Long): List<BillItem>
}
