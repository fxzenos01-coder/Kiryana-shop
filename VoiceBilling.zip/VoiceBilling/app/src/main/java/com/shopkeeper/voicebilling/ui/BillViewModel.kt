package com.shopkeeper.voicebilling.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shopkeeper.voicebilling.data.AppDatabase
import com.shopkeeper.voicebilling.data.Bill
import com.shopkeeper.voicebilling.data.BillItem
import com.shopkeeper.voicebilling.data.Product
import com.shopkeeper.voicebilling.data.ProductAlias
import com.shopkeeper.voicebilling.data.Repository
import com.shopkeeper.voicebilling.logic.AppLanguage
import com.shopkeeper.voicebilling.logic.Dictionary
import com.shopkeeper.voicebilling.logic.MatchResult
import com.shopkeeper.voicebilling.logic.Normalizer
import com.shopkeeper.voicebilling.logic.ParsedItem
import com.shopkeeper.voicebilling.logic.ProductMatcher
import com.shopkeeper.voicebilling.logic.Units
import com.shopkeeper.voicebilling.logic.VoiceParser
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BillViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = Repository(AppDatabase.get(app))

    val products: StateFlow<List<Product>> =
        repo.products.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val aliases: StateFlow<List<ProductAlias>> =
        repo.aliases.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val bills: StateFlow<List<Bill>> =
        repo.bills.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _snacks = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val snacks: SharedFlow<String> = _snacks

    var screen by mutableStateOf(Screen.BILL)
    var language by mutableStateOf(AppLanguage.ROMAN_URDU)

    /** The bill being built. Nothing here is saved until the shopkeeper confirms. */
    var lines by mutableStateOf<List<DraftLine>>(emptyList())
        private set

    // ---- voice session state ----
    var listening by mutableStateOf(false)
    var partialText by mutableStateOf("")
    var heardText by mutableStateOf("")
    var inputText by mutableStateOf("")
    var voiceMessage by mutableStateOf<String?>(null)
    var voiceSessionIds by mutableStateOf<Set<Long>>(emptySet())
        private set

    // ---- dialogs ----
    var editor by mutableStateOf<EditorState?>(null)
        private set
    var showAddItem by mutableStateOf(false)
    var pickerForLineId by mutableStateOf<Long?>(null)

    private var nextId = 1L

    private fun snack(msg: String) {
        _snacks.tryEmit(msg)
    }

    private fun catalog() = Repository.buildCatalog(products.value, aliases.value)

    // =====================================================================
    // Voice session
    // =====================================================================

    fun startVoiceSession() {
        voiceSessionIds = emptySet()
        inputText = ""
        heardText = ""
        partialText = ""
        voiceMessage = null
        screen = Screen.VOICE
    }

    /** Throws away everything recognised in this voice session. */
    fun cancelVoice() {
        val ids = voiceSessionIds
        lines = lines.filterNot { it.id in ids }
        voiceSessionIds = emptySet()
        inputText = ""
        heardText = ""
        partialText = ""
        voiceMessage = null
        listening = false
        screen = Screen.BILL
    }

    fun confirmVoice() {
        listening = false
        partialText = ""
        screen = Screen.CONFIRM
    }

    fun leaveVoice() {
        listening = false
        partialText = ""
        screen = Screen.BILL
    }

    fun onSpeechFinal(text: String, confidence: Float?) {
        partialText = ""
        heardText = text
        val low = confidence != null && confidence > 0f && confidence < LOW_CONFIDENCE
        if (low) {
            // Never turn a doubtful recognition into bill lines: let the shopkeeper repeat or correct it.
            inputText = text
            voiceMessage = "I am not sure I heard that correctly. Please speak again, or correct the text below and press Interpret."
        } else {
            voiceMessage = null
            interpret(text)
        }
    }

    fun onSpeechError(message: String) {
        partialText = ""
        voiceMessage = message
    }

    /** Manual text entry: also the fallback when speech recognition is unavailable. */
    fun interpretInput() {
        val t = inputText.trim()
        if (t.isEmpty()) return
        interpret(t)
        inputText = ""
    }

    private fun interpret(text: String) {
        val items = VoiceParser.parse(text)
        if (items.isEmpty()) {
            voiceMessage = "No products found in: \"$text\". Please repeat or type them."
            return
        }
        val newLines = items.map { buildLine(it) }
        lines = lines + newLines
        voiceSessionIds = voiceSessionIds + newLines.map { it.id }
        voiceMessage = null
    }

    private fun buildLine(item: ParsedItem): DraftLine {
        val base = DraftLine(
            id = nextId++,
            status = LineStatus.UNCLEAR,
            spokenText = item.spokenName,
            qtyText = item.quantity?.let { Units.formatQty(it) } ?: "",
            unit = item.unit ?: "",
            parseNote = item.note,
            fromVoice = true
        )
        if (item.spokenName.isBlank()) return base.copy(parseNote = item.note ?: "Product name not heard")

        return when (val m = ProductMatcher.match(item.spokenName, catalog())) {
            is MatchResult.Matched -> {
                val p = products.value.firstOrNull { it.id == m.productId }
                if (p == null) {
                    base.copy(status = LineStatus.NEW, dictEntry = Dictionary.suggest(item.spokenName))
                } else {
                    applyProduct(base, p, LineStatus.MATCHED)
                }
            }
            is MatchResult.Uncertain -> base.copy(status = LineStatus.UNCERTAIN, suggestions = m.candidates)
            MatchResult.NotFound -> base.copy(
                status = LineStatus.NEW,
                dictEntry = Dictionary.suggest(item.spokenName)
            )
        }
    }

    // =====================================================================
    // Line editing
    // =====================================================================

    private fun rateFor(p: Product, unit: String): Double? {
        val price = p.sellingPrice ?: return null
        if (unit.isBlank()) return null
        val conv = Units.convert(1.0, unit, p.unit) ?: return null
        return price * conv
    }

    /** Attaches [p] to the line, converting the unit when possible and never inventing a rate. */
    private fun applyProduct(line: DraftLine, p: Product, status: LineStatus): DraftLine {
        var unit = line.unit
        var qtyText = line.qtyText
        var note: String? = null
        val qty = line.quantity
        if (unit.isNotBlank() && unit != p.unit && qty != null) {
            val converted = Units.convert(qty, unit, p.unit)
            if (converted != null) {
                note = "Converted ${Units.formatQty(qty)} $unit to ${Units.formatQty(converted)} ${p.unit}"
                qtyText = Units.formatQty(converted)
                unit = p.unit
            } else {
                note = "Unit differs from the product unit (${p.unit}) - please check the rate"
            }
        }
        val rate = rateFor(p, unit)
        return line.copy(
            productId = p.id,
            status = status,
            unit = unit,
            qtyText = qtyText,
            rateText = rate?.let { Units.formatRate(it) } ?: "",
            rateEdited = false,
            suggestions = emptyList(),
            dictEntry = null,
            note = note
        )
    }

    private fun updateLine(id: Long, change: (DraftLine) -> DraftLine) {
        lines = lines.map { if (it.id == id) change(it) else it }
    }

    private fun sanitizeNumber(text: String): String {
        val sb = StringBuilder()
        var dot = false
        for (c in text) {
            if (c.isDigit()) sb.append(c)
            else if (c == '.' && !dot) { sb.append(c); dot = true }
        }
        return sb.toString()
    }

    fun updateQty(id: Long, text: String) = updateLine(id) { it.copy(qtyText = sanitizeNumber(text)) }

    fun updateRate(id: Long, text: String) =
        updateLine(id) { it.copy(rateText = sanitizeNumber(text), rateEdited = true) }

    fun updateUnit(id: Long, unit: String) {
        updateLine(id) { line ->
            val p = line.productId?.let { pid -> products.value.firstOrNull { it.id == pid } }
            if (p != null && !line.rateEdited) {
                line.copy(unit = unit, rateText = rateFor(p, unit)?.let { Units.formatRate(it) } ?: "", note = null)
            } else {
                line.copy(unit = unit)
            }
        }
    }

    fun removeLine(id: Long) {
        lines = lines.filterNot { it.id == id }
        voiceSessionIds = voiceSessionIds - id
    }

    /** The shopkeeper picked a product for a line (suggestion button or the product picker). */
    fun chooseProduct(lineId: Long, product: Product, status: LineStatus) {
        val line = lines.firstOrNull { it.id == lineId } ?: return
        updateLine(lineId) { applyProduct(it, product, status) }
        if (line.fromVoice && line.spokenText.isNotBlank()) {
            // A confirmed correction becomes an alias so the same wording matches next time.
            viewModelScope.launch { repo.addAliases(product.id, listOf(line.spokenText)) }
        }
    }

    fun chooseSuggestion(lineId: Long, productId: Long) {
        val p = products.value.firstOrNull { it.id == productId } ?: return
        chooseProduct(lineId, p, LineStatus.MANUAL)
    }

    fun addManualLine(product: Product, qtyText: String, unit: String) {
        val u = unit.ifBlank { product.unit }
        val line = DraftLine(
            id = nextId++,
            status = LineStatus.MANUAL,
            productId = product.id,
            qtyText = sanitizeNumber(qtyText),
            unit = u,
            rateText = rateFor(product, u)?.let { Units.formatRate(it) } ?: ""
        )
        lines = lines + line
    }

    fun clearBill() {
        lines = emptyList()
        voiceSessionIds = emptySet()
    }

    // =====================================================================
    // Saving the bill
    // =====================================================================

    val canConfirm: Boolean
        get() = lines.isNotEmpty() && lines.all { it.isComplete }

    fun confirmBill() {
        val current = lines
        if (current.isEmpty() || !current.all { it.isComplete }) {
            snack("Please fix the highlighted items before saving")
            return
        }
        val prods = products.value
        val lang = language
        val items = current.map {
            BillItem(
                billId = 0,
                productId = it.productId,
                name = lineName(it, prods, lang),
                quantity = it.quantity!!,
                unit = it.unit,
                rate = it.rate!!,
                total = it.total!!
            )
        }
        val total = Units.round2(items.sumOf { it.total })
        viewModelScope.launch {
            repo.saveBill(Bill(createdAt = System.currentTimeMillis(), total = total), items)
            lines = emptyList()
            voiceSessionIds = emptySet()
            screen = Screen.BILL
            snack("Bill saved: ${Units.formatMoney(total)}")
        }
    }

    suspend fun billItems(billId: Long): List<BillItem> = repo.itemsFor(billId)

    // =====================================================================
    // Product editor (new product / edit product)
    // =====================================================================

    private fun looksUrdu(s: String) = Normalizer.containsArabicScript(s)

    fun openEditorForLine(lineId: Long) {
        val line = lines.firstOrNull { it.id == lineId } ?: return
        val dict = line.dictEntry
        val spoken = line.spokenText.trim()
        val urduSpoken = looksUrdu(spoken)
        val form = if (dict != null) {
            ProductForm(
                name = dict.english,
                urdu = dict.urdu,
                roman = dict.roman,
                english = dict.english,
                category = dict.category,
                unit = line.unit
            )
        } else {
            ProductForm(
                name = if (urduSpoken) spoken else Dictionary.titleCase(spoken),
                urdu = if (urduSpoken) spoken else "",
                roman = if (urduSpoken) "" else Dictionary.titleCase(spoken),
                unit = line.unit
            )
        }
        val note = if (dict != null) {
            "Suggested spelling: ${dict.label(language)}. Please check and edit if needed."
        } else {
            "Spelling is not verified - please check the name."
        }
        editor = EditorState(
            openId = nextId++,
            forLineId = lineId,
            addToBill = false,
            editing = null,
            initial = form,
            suggestionNote = note
        )
    }

    fun openEditorNew(addToBill: Boolean) {
        editor = EditorState(
            openId = nextId++,
            forLineId = null,
            addToBill = addToBill,
            editing = null,
            initial = ProductForm()
        )
    }

    fun openEditorEdit(p: Product) {
        editor = EditorState(
            openId = nextId++,
            forLineId = null,
            addToBill = false,
            editing = p,
            initial = ProductForm(
                name = p.name,
                urdu = p.nameUrdu,
                roman = p.nameRoman,
                english = p.nameEnglish,
                category = p.category,
                unit = p.unit,
                purchase = p.purchasePrice?.let { Units.formatRate(it) } ?: "",
                selling = p.sellingPrice?.let { Units.formatRate(it) } ?: "",
                stock = p.stock?.let { Units.formatQty(it) } ?: ""
            )
        )
    }

    fun closeEditor() {
        editor = null
    }

    private fun editorError(msg: String) {
        editor = editor?.copy(error = msg)
    }

    fun saveProduct(f: ProductForm) {
        val st = editor ?: return
        val name = f.name.trim()
        if (name.isEmpty()) return editorError("Product name is required")
        if (f.unit.isBlank()) return editorError("Please choose a measurement unit")
        val selling = f.selling.trim().toDoubleOrNull()
        if (selling == null || selling < 0.0) return editorError("Please enter the selling price")
        val purchase: Double? = if (f.purchase.isBlank()) null else {
            f.purchase.trim().toDoubleOrNull() ?: return editorError("Purchase price is not a valid number")
        }
        val stock: Double? = if (f.stock.isBlank()) null else {
            f.stock.trim().toDoubleOrNull() ?: return editorError("Initial stock is not a valid number")
        }

        val names = listOf(name, f.urdu, f.roman, f.english)
        val (exact, similar) = Repository.checkDuplicates(
            names, catalog(), products.value, excludeId = st.editing?.id
        )
        if (exact != null) {
            editor = st.copy(
                error = "\"${exact.label(language)}\" already exists in your products.",
                duplicate = exact
            )
            return
        }
        if (similar.isNotEmpty() && !st.similarAcknowledged) {
            val list = similar.take(3).joinToString(", ") { it.label(language) }
            editor = st.copy(
                error = "Similar product exists: $list. Press Save again only if this is a different product.",
                similarAcknowledged = true,
                duplicate = null
            )
            return
        }

        val product = Product(
            id = st.editing?.id ?: 0,
            name = name,
            nameUrdu = f.urdu.trim(),
            nameRoman = f.roman.trim(),
            nameEnglish = f.english.trim(),
            category = f.category.trim(),
            unit = f.unit,
            purchasePrice = purchase,
            sellingPrice = selling,
            stock = stock
        )

        viewModelScope.launch {
            if (st.editing != null) {
                repo.updateProduct(product)
                snack("Product updated")
            } else {
                val spoken = st.forLineId
                    ?.let { id -> lines.firstOrNull { it.id == id }?.spokenText }
                    .orEmpty()
                val saved = repo.addProduct(product, listOfNotNull(spoken.takeIf { it.isNotBlank() }))
                if (st.forLineId != null) {
                    updateLine(st.forLineId) { applyProduct(it, saved, LineStatus.MANUAL) }
                }
                if (st.addToBill) addManualLine(saved, "", saved.unit)
                snack("Product added")
            }
            editor = null
        }
    }

    /** The editor found an existing product with the same name: use that instead of creating a copy. */
    fun useExistingFromEditor() {
        val st = editor ?: return
        val dup = st.duplicate ?: return
        if (st.forLineId != null) chooseProduct(st.forLineId, dup, LineStatus.MANUAL)
        if (st.addToBill) addManualLine(dup, "", dup.unit)
        editor = null
    }

    fun deleteProduct(p: Product) {
        viewModelScope.launch {
            repo.deleteProduct(p)
            editor = null
            snack("Product deleted")
        }
    }

    fun addAlias(productId: Long, text: String) {
        viewModelScope.launch { repo.addAliases(productId, listOf(text)) }
    }

    fun deleteAlias(id: Long) {
        viewModelScope.launch { repo.deleteAlias(id) }
    }

    companion object {
        private const val LOW_CONFIDENCE = 0.5f
    }
}
