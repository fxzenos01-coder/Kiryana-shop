package com.shopkeeper.voicebilling.logic

/**
 * Built-in spelling dictionary. It is NOT the product catalogue: entries here have no prices or units,
 * and nothing is added to a bill from it. It only supplies correctly spelled names when a spoken
 * product is not in the shopkeeper's catalogue yet.
 */
data class DictEntry(
    val english: String,
    val roman: String,
    val urdu: String,
    val category: String,
    val aliases: List<String> = emptyList()
) {
    /** Name shown for the selected language, with the English name in brackets for context. */
    fun label(lang: AppLanguage): String = when (lang) {
        AppLanguage.ENGLISH -> if (english.equals(roman, true)) english else "$english ($roman)"
        AppLanguage.ROMAN_URDU -> if (english.equals(roman, true)) roman else "$roman ($english)"
        AppLanguage.URDU -> "$urdu ($english)"
    }

    fun allNames(): List<String> = listOf(english, roman, urdu) + aliases
}

object Dictionary {

    val entries: List<DictEntry> = listOf(
        DictEntry("Rice", "Chawal", "چاول", "Grains", listOf("chaawal", "chwal", "rice")),
        DictEntry("Basmati Rice", "Basmati Chawal", "باسمتی چاول", "Grains", listOf("basmati")),
        DictEntry("Wheat", "Gandum", "گندم", "Grains", listOf("gandam", "wheat")),
        DictEntry("Flour", "Aata", "آٹا", "Grains", listOf("atta", "aata", "ata", "flour")),
        DictEntry("Semolina", "Suji", "سوجی", "Grains", listOf("sooji", "semolina")),
        DictEntry("Vermicelli", "Sewaiyan", "سویاں", "Grains", listOf("seviyan", "sevaiyan", "vermicelli")),
        DictEntry("Sugar", "Cheeni", "چینی", "Essentials", listOf("chini", "cheni", "sugar")),
        DictEntry("Jaggery", "Gur", "گڑ", "Essentials", listOf("gurr", "jaggery")),
        DictEntry("Salt", "Namak", "نمک", "Essentials", listOf("salt")),
        DictEntry("Cooking Oil", "Tel", "تیل", "Essentials", listOf("oil", "cooking oil", "canola oil")),
        DictEntry("Ghee", "Ghee", "گھی", "Essentials", listOf("ghi", "desi ghee")),
        DictEntry("Tea", "Chai Patti", "چائے پتی", "Essentials", listOf("chai", "chay", "tea", "patti")),
        DictEntry("Milk", "Doodh", "دودھ", "Dairy", listOf("dudh", "milk")),
        DictEntry("Yogurt", "Dahi", "دہی", "Dairy", listOf("dahi", "yogurt", "yoghurt", "curd")),
        DictEntry("Butter", "Makhan", "مکھن", "Dairy", listOf("makkhan", "butter")),
        DictEntry("Cheese", "Paneer", "پنیر", "Dairy", listOf("panir", "cheese")),
        DictEntry("Eggs", "Anday", "انڈے", "Dairy", listOf("ande", "anda", "egg", "eggs")),
        DictEntry("Red Chilli", "Lal Mirch", "لال مرچ", "Spices", listOf("lal mirchi", "red chili", "red chilli", "mirch", "mirchi")),
        DictEntry("Black Pepper", "Kali Mirch", "کالی مرچ", "Spices", listOf("kali mirchi", "black pepper")),
        DictEntry("Turmeric", "Haldi", "ہلدی", "Spices", listOf("haldee", "turmeric")),
        DictEntry("Cumin", "Zeera", "زیرہ", "Spices", listOf("jeera", "zira", "jira", "zeera", "cumin")),
        DictEntry("Coriander", "Dhania", "دھنیا", "Spices", listOf("dhaniya", "dhanya", "coriander")),
        DictEntry("Garam Masala", "Garam Masala", "گرم مسالہ", "Spices", listOf("garam masalah")),
        DictEntry("Cardamom", "Elaichi", "الائچی", "Spices", listOf("ilaichi", "elachi", "cardamom")),
        DictEntry("Cloves", "Laung", "لونگ", "Spices", listOf("long", "cloves")),
        DictEntry("Cinnamon", "Dalchini", "دار چینی", "Spices", listOf("daar cheeni", "dar chini", "cinnamon")),
        DictEntry("Fennel", "Saunf", "سونف", "Spices", listOf("sonf", "fennel")),
        DictEntry("Mustard Seeds", "Sarson", "سرسوں", "Spices", listOf("sarsoon", "mustard")),
        DictEntry("Lentils (Masoor)", "Daal Masoor", "دال مسور", "Pulses", listOf("dal masoor", "masoor", "masoor dal", "red lentils")),
        DictEntry("Lentils (Chana)", "Daal Chana", "دال چنا", "Pulses", listOf("dal chana", "chana dal")),
        DictEntry("Lentils (Moong)", "Daal Moong", "دال مونگ", "Pulses", listOf("dal moong", "moong dal", "moong")),
        DictEntry("Lentils (Mash)", "Daal Mash", "دال ماش", "Pulses", listOf("dal mash", "mash dal", "mash")),
        DictEntry("Chickpeas", "Chana", "چنا", "Pulses", listOf("channa", "chickpeas", "kala chana")),
        DictEntry("Onion", "Pyaz", "پیاز", "Vegetables", listOf("piyaz", "pyaaz", "onion")),
        DictEntry("Potato", "Aloo", "آلو", "Vegetables", listOf("alu", "potato")),
        DictEntry("Tomato", "Tamatar", "ٹماٹر", "Vegetables", listOf("tamater", "tomato")),
        DictEntry("Garlic", "Lehsan", "لہسن", "Vegetables", listOf("lahsan", "lasan", "garlic")),
        DictEntry("Ginger", "Adrak", "ادرک", "Vegetables", listOf("adrakh", "ginger")),
        DictEntry("Dates", "Khajoor", "کھجور", "Dry Fruit", listOf("khajur", "dates")),
        DictEntry("Almonds", "Badam", "بادام", "Dry Fruit", listOf("badaam", "almonds")),
        DictEntry("Bread", "Double Roti", "ڈبل روٹی", "Bakery", listOf("dabal roti", "bread")),
        DictEntry("Biscuits", "Biscuit", "بسکٹ", "Bakery", listOf("biscuits", "biskut")),
        DictEntry("Soap", "Sabun", "صابن", "Household", listOf("saabun", "soap"))
    )

    private val catalog: List<CatalogEntry> = entries.mapIndexed { i, e ->
        CatalogEntry(i.toLong(), e.english, e.allNames())
    }

    /**
     * Best dictionary entry for a spoken name, or null. Only ever a suggestion - the shopkeeper
     * confirms or edits it before anything is saved.
     */
    fun suggest(spoken: String): DictEntry? {
        return when (val r = ProductMatcher.match(spoken, catalog)) {
            is MatchResult.Matched -> entries[r.productId.toInt()]
            is MatchResult.Uncertain -> r.candidates.firstOrNull { it.score >= 0.75 }?.let { entries[it.productId.toInt()] }
            MatchResult.NotFound -> null
        }
    }

    private val byKey: Map<String, DictEntry> by lazy {
        val m = HashMap<String, DictEntry>()
        for (e in entries) {
            for (n in e.allNames()) {
                val k = ProductMatcher.key(n)
                if (k.isNotEmpty()) m.putIfAbsent(k, e)
            }
        }
        m
    }

    /**
     * Adds the built-in Urdu / Roman Urdu / English names of a product whose name is spelled exactly
     * like a dictionary entry, so a product saved as "Sugar" is also found when "cheeni" or "چینی"
     * is spoken. Only identical spellings are expanded - never similar ones.
     */
    fun expand(names: List<String>): List<String> {
        val out = LinkedHashSet<String>(names)
        for (n in names) {
            val k = ProductMatcher.key(n)
            if (k.isEmpty()) continue
            byKey[k]?.let { out.addAll(it.allNames()) }
        }
        return out.toList()
    }

    /** True when two different dictionary entries share a spelling key (used by a unit test). */
    fun hasKeyCollisions(): List<String> {
        val seen = HashMap<String, Int>()
        val clashes = ArrayList<String>()
        entries.forEachIndexed { idx, e ->
            for (n in e.allNames()) {
                val k = ProductMatcher.key(n)
                if (k.isEmpty()) continue
                val prev = seen.putIfAbsent(k, idx)
                if (prev != null && prev != idx) clashes.add("$n clashes with ${entries[prev].english}")
            }
        }
        return clashes
    }

    /** "basmati chawal" -> "Basmati Chawal". Used only when the dictionary has nothing. */
    fun titleCase(s: String): String =
        s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            .joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercaseChar() } }
}
