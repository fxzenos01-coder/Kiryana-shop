package com.shopkeeper.voicebilling.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Speech recognition only. It turns audio into text and nothing else: product matching,
 * spelling correction, measurement parsing and money maths live elsewhere.
 *
 * Uses the phone's own recogniser with "prefer offline". Whether it really runs offline depends on
 * the offline language pack installed on the phone - the app cannot guarantee it.
 */
class SpeechController(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onListeningChanged(listening: Boolean)
        fun onPartial(text: String)
        /** [confidence] is null when the engine did not report one. */
        fun onFinal(text: String, confidence: Float?)
        fun onError(message: String)
    }

    private var recognizer: SpeechRecognizer? = null

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun start(languageTag: String) {
        if (!isAvailable()) {
            listener.onError("Speech recognition is not available on this phone. Please type the bill instead.")
            return
        }
        destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = listener.onListeningChanged(true)
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                listener.onListeningChanged(false)
                listener.onError(errorMessage(error))
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!t.isNullOrBlank()) listener.onPartial(t)
            }

            override fun onResults(results: Bundle?) {
                listener.onListeningChanged(false)
                val texts = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val best = texts?.firstOrNull()
                if (best.isNullOrBlank()) {
                    listener.onError("Nothing was recognised. Please try again or type the bill.")
                    return
                }
                val conf = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)?.firstOrNull()
                listener.onFinal(best, conf)
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        try {
            r.startListening(intent)
        } catch (e: Exception) {
            listener.onListeningChanged(false)
            listener.onError("Could not start listening. Please type the bill instead.")
        }
    }

    /** Stop listening and deliver what was heard so far. */
    fun stop() {
        recognizer?.stopListening()
    }

    /** Stop listening and discard whatever was heard. */
    fun cancel() {
        recognizer?.cancel()
        listener.onListeningChanged(false)
    }

    fun destroy() {
        recognizer?.destroy()
        recognizer = null
    }

    private fun errorMessage(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH -> "Could not understand. Please repeat or type the bill."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech heard. Press the microphone and speak again."
        SpeechRecognizer.ERROR_AUDIO -> "Microphone problem. Please try again."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is needed for voice billing."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            "This language needs the phone's offline speech pack or internet. You can type the bill instead."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech service is busy. Please try again."
        12, 13 -> "This language is not available for offline recognition on this phone. You can type the bill instead."
        else -> "Speech recognition failed (code $code). Please repeat or type the bill."
    }
}
