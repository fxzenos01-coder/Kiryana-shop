package com.shopkeeper.voicebilling.logic

import java.util.Locale

/** Measurement units and conversions. Measurement interpretation only - no prices here. */
object Units {
    const val KG = "kg"
    const val G = "g"
    const val L = "l"
    const val ML = "ml"
    const val DOZEN = "dozen"
    const val PIECE = "piece"
    const val PACK = "pack"

    /** Units offered in drop-downs. */
    val all: List<String> = listOf(KG, G, L, ML, DOZEN, PIECE, PACK)

    /** Converts [qty] between compatible units, or returns null when conversion is impossible. */
    fun convert(qty: Double, from: String, to: String): Double? {
        if (from == to) return qty
        return when {
            from == KG && to == G -> qty * 1000.0
            from == G && to == KG -> qty / 1000.0
            from == L && to == ML -> qty * 1000.0
            from == ML && to == L -> qty / 1000.0
            from == DOZEN && to == PIECE -> qty * 12.0
            from == PIECE && to == DOZEN -> qty / 12.0
            else -> null
        }
    }

    fun formatQty(q: Double): String {
        val rounded = Math.round(q * 1000.0) / 1000.0
        return if (rounded == Math.floor(rounded) && Math.abs(rounded) < 1e9) {
            rounded.toLong().toString()
        } else {
            String.format(Locale.US, "%.3f", rounded).trimEnd('0').trimEnd('.')
        }
    }

    /** Rate text for an input box: up to 4 decimals, no trailing zeros. */
    fun formatRate(r: Double): String {
        val s = String.format(Locale.US, "%.4f", r).trimEnd('0').trimEnd('.')
        return if (s.isEmpty() || s == "-") "0" else s
    }

    fun round2(x: Double): Double = Math.round(x * 100.0) / 100.0

    fun formatMoney(m: Double): String {
        val rounded = Math.round(m * 100.0) / 100.0
        return if (rounded == Math.floor(rounded)) {
            "Rs. " + rounded.toLong().toString()
        } else {
            "Rs. " + String.format(Locale.US, "%.2f", rounded)
        }
    }
}
