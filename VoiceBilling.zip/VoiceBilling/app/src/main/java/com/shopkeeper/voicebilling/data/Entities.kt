package com.shopkeeper.voicebilling.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.shopkeeper.voicebilling.logic.AppLanguage

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val nameUrdu: String = "",
    val nameRoman: String = "",
    val nameEnglish: String = "",
    val category: String = "",
    val unit: String,
    val purchasePrice: Double? = null,
    val sellingPrice: Double? = null,
    val stock: Double? = null
) {
    /** Name shown for the selected language, e.g. "Zeera (Cumin)" in Roman Urdu mode. */
    fun label(lang: AppLanguage): String {
        val eng = nameEnglish.ifBlank { name }
        val rom = nameRoman
        val urd = nameUrdu
        val primary = when (lang) {
            AppLanguage.ENGLISH -> eng
            AppLanguage.ROMAN_URDU -> rom.ifBlank { eng }
            AppLanguage.URDU -> urd.ifBlank { rom.ifBlank { eng } }
        }
        val secondary = when (lang) {
            AppLanguage.ENGLISH -> rom
            else -> eng
        }
        return if (secondary.isBlank() || secondary.equals(primary, ignoreCase = true)) {
            primary
        } else {
            "$primary ($secondary)"
        }
    }
}

@Entity(
    tableName = "product_aliases",
    foreignKeys = [
        ForeignKey(
            entity = Product::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["productId", "alias"], unique = true)]
)
data class ProductAlias(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val alias: String
)

@Entity(tableName = "bills")
data class Bill(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long,
    val total: Double
)

@Entity(
    tableName = "bill_items",
    foreignKeys = [
        ForeignKey(
            entity = Bill::class,
            parentColumns = ["id"],
            childColumns = ["billId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("billId")]
)
data class BillItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val billId: Long,
    val productId: Long?,
    val name: String,
    val quantity: Double,
    val unit: String,
    val rate: Double,
    val total: Double
)
