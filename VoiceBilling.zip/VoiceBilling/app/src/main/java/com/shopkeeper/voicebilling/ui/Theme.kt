package com.shopkeeper.voicebilling.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val colors = lightColorScheme(
    primary = Color(0xFF1B5E20),
    onPrimary = Color.White,
    secondary = Color(0xFF2E7D32),
    onSecondary = Color.White,
    background = Color(0xFFF6F8F5),
    surface = Color.White,
    error = Color(0xFFB3261D)
)

@Composable
fun VoiceBillingTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = colors, content = content)
}
