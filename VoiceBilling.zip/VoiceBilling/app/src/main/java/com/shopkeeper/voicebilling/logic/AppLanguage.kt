package com.shopkeeper.voicebilling.logic

/**
 * The three voice-assistant languages.
 * [speechTag] is the locale handed to the phone's speech recogniser.
 * Roman Urdu has no recogniser of its own: the phone recognises Urdu speech (Urdu script) and the
 * Roman Urdu mode only changes how names are shown and how typed text is read.
 */
enum class AppLanguage(val label: String, val speechTag: String) {
    ENGLISH("English", "en-US"),
    ROMAN_URDU("Roman Urdu", "ur-PK"),
    URDU("Urdu (اردو)", "ur-PK")
}
