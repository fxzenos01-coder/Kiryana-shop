@file:OptIn(ExperimentalMaterial3Api::class)

package com.shopkeeper.voicebilling.ui

import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun VoiceBillingApp(vm: BillViewModel = viewModel()) {
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) {
        vm.snacks.collect { snackbar.showSnackbar(it) }
    }
    val products by vm.products.collectAsState()
    val aliases by vm.aliases.collectAsState()

    BackHandler(enabled = vm.screen != Screen.BILL) {
        if (vm.screen == Screen.VOICE) vm.leaveVoice() else vm.screen = Screen.BILL
    }

    val title = when (vm.screen) {
        Screen.BILL -> "Voice Billing"
        Screen.VOICE -> "AI Voice Billing"
        Screen.CONFIRM -> "Confirm bill"
        Screen.PRODUCTS -> "Products"
        Screen.HISTORY -> "Saved bills"
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    if (vm.screen != Screen.BILL) {
                        IconButton(onClick = {
                            if (vm.screen == Screen.VOICE) vm.leaveVoice() else vm.screen = Screen.BILL
                        }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    if (vm.screen == Screen.BILL) {
                        val white = ButtonDefaults.textButtonColors(contentColor = Color.White)
                        TextButton(onClick = { vm.screen = Screen.PRODUCTS }, colors = white) { Text("Products") }
                        TextButton(onClick = { vm.screen = Screen.HISTORY }, colors = white) { Text("History") }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        when (vm.screen) {
            Screen.BILL -> BillScreen(vm, padding)
            Screen.VOICE -> VoiceScreen(vm, padding)
            Screen.CONFIRM -> ConfirmScreen(vm, padding)
            Screen.PRODUCTS -> ProductsScreen(vm, padding)
            Screen.HISTORY -> HistoryScreen(vm, padding)
        }
    }

    // ---- dialogs (shown over any screen) ----

    vm.editor?.let { st ->
        ProductEditorDialog(
            state = st,
            language = vm.language,
            aliases = aliases,
            onSave = { vm.saveProduct(it) },
            onDismiss = { vm.closeEditor() },
            onUseExisting = { vm.useExistingFromEditor() },
            onDelete = { vm.deleteProduct(it) },
            onAddAlias = { id, text -> vm.addAlias(id, text) },
            onDeleteAlias = { vm.deleteAlias(it) }
        )
    }

    vm.pickerForLineId?.let { lineId ->
        ProductPickerDialog(
            products = products,
            aliases = aliases,
            language = vm.language,
            onPick = { p ->
                vm.chooseProduct(lineId, p, LineStatus.MANUAL)
                vm.pickerForLineId = null
            },
            onCreateNew = {
                vm.pickerForLineId = null
                vm.openEditorForLine(lineId)
            },
            onDismiss = { vm.pickerForLineId = null }
        )
    }

    if (vm.showAddItem) {
        AddItemDialog(
            products = products,
            aliases = aliases,
            language = vm.language,
            onAdd = { p, qty, unit ->
                vm.addManualLine(p, qty, unit)
                vm.showAddItem = false
            },
            onCreateNew = {
                vm.showAddItem = false
                vm.openEditorNew(true)
            },
            onDismiss = { vm.showAddItem = false }
        )
    }
}
