# PROJECT BRIEF — Voice Billing (shopkeeper app)

Use this file as the standing prompt for any future work on this project (by me, by Claude, or by another developer). Read it fully before changing code.

## 1. Goal

An Android app for a Pakistani shopkeeper to build a bill by voice or by hand.
Voice is optional help: the shopkeeper presses a microphone button, speaks in English, Roman Urdu, Urdu or a mix, reviews what the app understood, fixes anything wrong, and only then saves the bill.

Accuracy is more important than speed. A wrong guess must never become a financial record.

## 2. Hard rules (never break these)

- Never invent a product, a price or a measurement unit.
- Never silently replace one product with another. Close-but-not-identical matches are shown as suggestions; the shopkeeper chooses.
- Never create a duplicate product without checking existing products and aliases.
- Never finalise or save a bill without the shopkeeper pressing Confirm.
- Never save an unconfirmed voice transaction.
- Never treat an unclear quantity as confirmed (quantity stays empty until stated or typed).
- Voice never starts by itself; it listens only after the microphone button is pressed.
- Low speech confidence means: ask to repeat or correct, do not create bill lines.
- Do not claim perfect recognition. Do not claim speech recognition is offline unless it is.
- Keep these five things separate in code and in the UI wording:
  1. speech recognition (`speech/SpeechController`)
  2. product matching (`logic/ProductMatcher`)
  3. product-name correction (`logic/Dictionary`, aliases)
  4. measurement interpretation (`logic/VoiceParser`, `logic/Units`)
  5. financial calculation (`ui/Models.kt` DraftLine.total, rounding in `Units.round2`)

## 3. Requirements and where each is implemented

| # | Requirement | Where |
|---|---|---|
| 1 | Separate "AI Voice Billing" button, separate from manual entry; listening indicator; Stop / Cancel / Confirm; manual editing stays available | `ui/Screens.kt` (BillScreen, VoiceScreen) |
| 2 | Three language buttons (English, Roman Urdu, Urdu), switchable any time; language drives the recogniser locale and how names are shown | `logic/AppLanguage.kt`, VoiceScreen chips, `Product.label(lang)` |
| 3 | New-product recognition: search names + aliases, fuzzy check, detect genuinely new, suggest spelling, edit, add to catalogue, ask unit + selling price, add as its own bill row | `BillViewModel.buildLine/openEditorForLine/saveProduct`, `ProductEditorDialog` |
| 4 | Local dictionary (English / Urdu / Roman Urdu / regional / custom); multiple suggestions when unsure; confirmed corrections saved as aliases | `logic/Dictionary.kt`, `data/ProductAlias`, `BillViewModel.chooseProduct` |
| 5 | Accuracy rules (section 2) | whole app; `DraftLine.isComplete` gates saving |
| 6 | Editable confirmation screen (product, qty, unit, rate, total; edit/remove/add) | `ConfirmScreen`, `LineCard` |
| 7 | Offline intelligence: matching, aliases, unit conversion, billing maths all local; speech uses the phone's recogniser with "prefer offline"; typed-text fallback | `logic/*`, `SpeechController`, "Type or correct the bill here" box |

## 4. Design

- Native Android: Kotlin, Jetpack Compose (Material 3), Room database. Single activity, one ViewModel (`BillViewModel`), screens switched by `Screen` enum.
- Colour: deep green primary (`ui/Theme.kt`), white cards, red outline on any bill line that is not complete, status text per line (Matched, Check spelling, New product, Confirmed, Choose product).
- Large tap targets (shopkeeper use): 64 dp voice button, 96 dp mic.
- Every price/quantity field is plain text the shopkeeper can overwrite.

## 5. Architecture

```
logic/   pure Kotlin, no Android imports, unit-tested on the JVM
  Normalizer   text/Urdu-letter/digit normalisation
  Lexicon      number, unit and filler words (EN / Roman Urdu / Urdu)
  VoiceParser  sentence -> items (name, quantity?, unit?)
  ProductMatcher  spelling-tolerant matching: Matched / Uncertain / NotFound
  Dictionary   built-in spelling dictionary (suggestions only, no prices)
  Units        unit conversion and number/money formatting
data/    Room: Product, ProductAlias, Bill, BillItem, DAOs, Repository
speech/  SpeechController (wraps android.speech.SpeechRecognizer)
ui/      BillViewModel, Models, Components, Screens, VoiceBillingApp, Theme
```

Matching result meanings:
- `Matched` = identical after spelling normalisation (chawal / chaawal). Still shown to the shopkeeper.
- `Uncertain` = similar only. Shown as suggestion buttons. Never auto-selected.
- `NotFound` = probably new. Dictionary suggests a spelled name; shopkeeper confirms in the editor.

## 6. Status

Done and verified:
- `logic/` compiled and run on a JVM: 21 unit tests pass (parser in 3 languages, number words, paon/dhai/derh, missing connectors, matcher guard rails, dictionary suggestions, built-in-name expansion, unit conversion).
- Full project written: Gradle (Kotlin DSL), manifest, resources, Room layer, speech wrapper, all screens, GitHub Actions workflow that runs tests and builds the APK.

Not verified by the author's tooling (no Android SDK available there):
- The Android layer (Room + Compose + speech) was carefully read and cross-reviewed but never compiled by the author. The first GitHub Actions run is the first real compile. If it fails, copy the first red error into a new chat with this file.
- Real-phone speech accuracy for Urdu is untested. It depends on the phone's speech service and installed language packs.

## 7. Known limits (be honest in the UI and with users)

- Roman Urdu has no recogniser of its own; the phone recognises Urdu speech (Urdu script), and the app matches it using Urdu names/aliases. Roman Urdu mode changes how names are displayed and how typed text is read.
- Offline voice works only if the phone has the offline pack for that language (Google "Speech Services" > Offline speech recognition). Otherwise use the typing box. The app never claims otherwise.
- Matching is spelling-based, not a language model. Unusual words need the shopkeeper's one-time correction; after that the alias is remembered.

## 8. Next steps / ideas (not built)

1. Bundle an on-device model (for example Vosk or Whisper) for guaranteed offline Urdu speech. Needs a model download and licence check.
2. Receipt printing / PDF share, customer names, udhaar (credit) ledger.
3. Stock deduction on sale, low-stock alerts, CSV export/backup of the database.
4. Release signing with your own keystore for Play Store.
5. Instrumented UI tests.

## 9. Working rules for whoever continues

- Keep `logic/` free of Android imports; add a unit test for every behaviour change there.
- Run the logic tests on every change. They are in `app/src/test/.../LogicTest.kt` and run with `./gradlew :app:testDebugUnitTest`.
- After any change: build with GitHub Actions or Android Studio and install on a phone.
- Update section 6 of this file when something changes.
